﻿using jeyjen.extension;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml.Linq;

internal static class op
{
    #region order
    public static void get_order(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");

            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.soz_driver[contour];
            var order_id = content.get<long>("order");
            var orders = driver.get_order(order_id);
            if (orders.count == 0)
            {
                error(new Exception("не найдена заявка с № {0}".format(order_id)));
                return;
            }
            var attrs = new List<dentity>();
            var res = new dentity();
            var o = orders[0];
            res["order_id"] = o.get<long>("documentid");
            res["type"] = o.get<long>("documenttype");
            res["date"] = o.get<string>("creationdate");
            res["created_by"] = o.get<string>("createdby");
            res["state"] = o.get<string>("state");
            res["ext1date"] = o.get<string>("ext1date", "");
            res["ext2date"] = o.get<string>("ext2date", "");
            res["ext3date"] = o.get<string>("ext3date", "");
            res["ext4date"] = o.get<string>("ext4date", "");
            res["ext5date"] = o.get<string>("ext5date", "");
            res["string1"] = o.get<string>("string1", "");
            res["string2"] = o.get<string>("string2", "");
            res["string3"] = o.get<string>("string3", "");
            res["string4"] = o.get<string>("string4", "");
            res["string5"] = o.get<string>("string5", "");
            res["int1"] = o.get<string>("int1", "");
            res["int2"] = o.get<string>("int2", "");
            res["int3"] = o.get<string>("int3", "");
            res["int4"] = o.get<string>("int4", "");
            res["int5"] = o.get<string>("int5", "");
            res["amount1"] = o.get<string>("amount1", "");
            res["amount1"] = o.get<string>("amount2", "");
            res["amount3"] = o.get<string>("amount3", "");
            res["amount4"] = o.get<string>("amount4", "");
            res["amount5"] = o.get<string>("amount5", "");
            res["attributes"] = attrs;

            List<string> satr = null;
            if (content.contains("attributes"))
            {
                satr = new List<string>();
                var ats = content.get<List<dynamic>>("attributes");
                foreach (var attr in ats)
                {
                    satr.Add(attr);
                }
            }

            if (satr == null || satr.Count > 0)
            {
                var b_attrs = driver.get_attributes(order_id, satr);
                foreach (var b_attr in b_attrs)
                {
                    var path = b_attr.get<string>("attrpath");
                    if (path.Equals("/root"))
                    {
                        continue;
                    }
                    var a = new dentity();
                    a["name"] = path.Split('/')[2];
                    a["value"] = b_attr.get<string>("attrvalue", "");
                    attrs.Add(a);
                }
            }
            result(res);

        }
        catch (Exception e)
        {
            error(e);
        }
    }
    public static void update_order(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var wss_driver = s.soz_wss_driver[contour];
            var driver = s.soz_driver[contour];

            var order_id = content.get<long>("order");
            var type = driver.get_type_by_id(order_id);

            Dictionary<string, int> types = null;
            if (type == 26 || type == 23)
            {
                types = s.card_type;
            }
            else if (type == 13)
            {
                types = s.cash_type;
            }

            var attrs = content.get<List<dynamic>>("attributes");
            var b = new bundle("attribute", "type", "value");
            var name = "";
            var value = "";
            foreach (var attr in attrs)
            {
                name = attr.get<string>("name");
                value = attr.get<string>("value");
                if (types.ContainsKey(name))
                {
                    b.add(name, types[name], value);
                }
                else
                {
                    b.add(name, 1, value);
                }
            }
            string request = wss_driver.update_order(order_id, b);
            try
            {
                var responce = wss_driver.send_request(request);
                var d = handle_response(responce);
                var oi = d.xml()
                        .Element("BODY")
                        .Element("Result").Value;
                var res = new dentity();
                res["order"] = long.Parse(oi);
                result(res);
            }
            catch (Exception e)
            {
                error(e);
            }
        }
        catch (Exception e)
        {
            error(new Exception("ошибка при формировании запроса: \"{0}\"".format(e.Message)));
        }
    }
    public static void generate_order(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.soz_driver[contour];
            var wss_driver = s.soz_wss_driver[contour];
            string request = "";
            if (content.contains("xml"))
            {
                request = content.get<string>("xml");
            }
            else
            {
                var o = new order(driver);
                var type = content.get<int>("type");
                var def_attrs = new Dictionary<string, string>();
                if (content.contains("attributes"))
                {
                    foreach (var item in content.get<List<dynamic>>("attributes"))
                    {
                        try
                        {
                            var a = item.get<string>("name");
                            var v = item.get<string>("value");
                            def_attrs.Add(a, v);
                        }
                        catch (Exception ex)
                        {
                        }
                    }
                }
                o.fill(type, def_attrs);
                Dictionary<string, int> types = null;
                if (type == 26 || type == 23)
                {
                    types = s.card_type;
                }
                else if (type == 13)
                {
                    types = s.cash_type;
                }
                var b = new bundle("attribute", "type", "value");
                foreach (var attr in o.attrs)
                {
                    if (!types.ContainsKey(attr.Key))
                    {
                        b.add(attr.Key, 1, attr.Value);
                    }
                    else
                    {
                        b.add(attr.Key, types[attr.Key], attr.Value);
                    }
                }
                request = wss_driver.save_application(b);
            }
            try
            {
                var responce = wss_driver.send_request(request);
                var d = handle_response(responce);
                var oi = d.xml()
                        .Element("BODY")
                        .Element("Result").Value;
                var res = new dentity();
                res["order"] = int.Parse(oi);
                result(res);
            }
            catch (Exception e)
            {
                error(e);
            }
        }
        catch (Exception e)
        {
            if (e.Message.Contains("Connection request timed out")
                || e.Message.Contains("No listener"))
            {
                error(new Exception("БД СОЗа не отвечает, причина: \"{0}\"".format(e.Message)));
            }
            else
            {
                error(new Exception("ошибка при генерации: \"{0}\"".format(e.Message)));
            }
        }
    }
    public static void set_rate(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.soz_driver[contour];
            var wss_driver = s.soz_wss_driver[contour];

            long order_id = content.get<long>("order");

            double rate = 0;
            if (content.contains("rate"))
            {
                rate = content.get<double>("rate");
            }
            if (rate == 0)
            {
                var product = driver.get_attribute_value(order_id, "Product_Program");
                var term = int.Parse(driver.get_attribute_value(order_id, "Product_Term"));
                if (product.Equals("Персональный плюс") || product.Equals("Персональный"))
                {
                    if (term <= 24)
                    {
                        rate = 14.9;
                    }
                    else
                    {
                        rate = 15.9;
                    }
                }
                else if (product.Equals("Уважительный"))
                {
                    rate = 26.9;
                }
                else if (product.Equals("Профессионал") || product.Equals("Профессионал плюс"))
                {
                    if (term >= 12 && term <= 24)
                    {
                        rate = 16.9;
                    }
                    else if (25 <= term && term <= 60)
                    {
                        rate = 18.5;
                    }
                }
                else if (product.Equals("Партнер"))
                {
                    rate = 24.5;
                }
                else if (product.Contains("Нужные вещи"))
                {
                    if (term <= 12)
                    {
                        rate = 19.9;
                    }
                    else
                    {
                        rate = 19.9;
                    }
                }
            }
            var attrs = new bundle("attribute", "value", "type");
            var v = rate.ToString(CultureInfo.InvariantCulture);
            attrs.add("approved_CreditRate", v, 1);
            attrs.add("Approved_CreditRateString", "{0};{0}".format(v), 1);

            string request = wss_driver.update_order(order_id, attrs);
            try
            {
                var responce = wss_driver.send_request(request);
                var d = handle_response(responce);
                var oi = d.xml()
                        .Element("BODY")
                        .Element("Result").Value;
                var res = new dentity();
                res["rate"] = rate;
                result(res);
            }
            catch (Exception e)
            {
                error(e);
            }
        }
        catch (Exception e)
        {
            error(new Exception("Ошибка при установке ставок: {0}".format(e.Message)));
        }
    }
    
    #region card
    public static void attach_card(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (! s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.soz_driver[contour];
            var wss_driver = s.soz_wss_driver[contour];

            var order_id = content.get<long>("order");
            var cb = s.db.get_unused_cards(197);
            if (cb.count == 0)
            {
                throw new Exception("нет свободной карты");
            }
            var c = cb.first;
            var card_id = c.get<long>("card_id");
            var cards = driver.get_cards(card_id);
            if (cards.count == 0)
            {
                throw new Exception("В БД СОЗа {0} контура не найдена карта с id {1}".format(contour, card_id));
            }
            var card = cards.first;
            var type = driver.get_type_by_id(order_id);

            Dictionary<string, int> types = null;
            if (type == 26 || type == 23)
            {
                types = s.card_type;
            }
            else if (type == 13)
            {
                types = s.cash_type;
            }

            var n = card.get<string>("cardnumber");
            var pan = n.Substring(0, 6) + "XXXXXX" + n.Substring(12, 4);
            var date = card.get<DateTime>("expirationdate");
            var dv = "{0}/{1}".format(date.Month, date.ToString("yy"));

            var b = new bundle("attribute", "type", "value");
            b.add("CardInfo_CardId", types["CardInfo_CardId"], card_id);
            b.add("CardInfo_CardNum", types["CardInfo_CardNum"], pan);
            b.add("CardInfo_ExpireDate", types["CardInfo_ExpireDate"], dv);
            b.add("CardInfo_FIOLat", types["CardInfo_FIOLat"], "HUA EGOROV");
            b.add("CardInfo_SecretWord", types["CardInfo_SecretWord"], "дидюля");
            string request = wss_driver.update_order(order_id, b);
            try
            {
                var responce = wss_driver.send_request(request);
                var d = handle_response(responce);
                var oi = d.xml()
                        .Element("BODY")
                        .Element("Result").Value;
                var res = new dentity();
                res["card_id"] = card_id;
                result(res);

                // пометить карту ка использованную
                s.db.set_card_as_used(card_id);
            }
            catch (Exception e)
            {
                error(new Exception("ошибка при запросе СОЗа на обновление заявки: {0}".format(e.Message)));
            }
        }
        catch (Exception ex)
        {
            error(new Exception("Ошибка во время прикрепления карты: {0}".format(ex.Message)));
        }
    }
    #endregion
    #region stage
    public static void set_stage(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var wss_driver = s.soz_wss_driver[contour];
            var driver = s.soz_driver[contour];

            var attributes = new bundle("name", "value");
            var order_id = content.get<long>("order");
            var stage = content.get<string>("name");
            
            if (stage == "Внебалансовый учет карт")
            {
                var v = driver.get_attribute_value(order_id, "CardInfo_CardId");
                attributes.add("CardInfo_CardId", v);
            }
            else if (stage == "Подготовка документов завершена")
            {
                attributes.add("ApplicationID", order_id);
            }
            else if (stage == "Подписание документов")
            {
                attributes.add("ApplicationID", order_id);
            }

            if (content.contains("attributes"))
            {
                foreach (var item in content.get<List<dynamic>>("attributes"))
                {
                    attributes.add(item.get<string>("name"), item.get<string>("value"));
                }
            }
            var performer = content.get<string>("performer");
            performer = performer.is_null_or_empty() ? "crd_noface" : performer;
            var query = wss_driver.set_stage(order_id, stage, content.get<string>("result"), performer, attributes);
            var responce = wss_driver.send_request(query);

            var d = handle_response(responce);
            var stage_id = d.xml()
                    .Element("BODY")
                    .Element("Result")
                    .Element("STAGEID").Value;
            var res = new dentity();
            res["stage"] = int.Parse(stage_id);
            result(res);
        }
        catch (Exception e)
        {
            error(e);
        }
    }
    public static void get_stages(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        var contour = content.get<string>("contour");
        if (!s.soz_driver.ContainsKey(contour))
        {
            error(new Exception("контур \"{0}\" не определен".format(contour)));
        }
        var db_driver = s.soz_driver[contour];
        var order = content.get<long>("order");
        var name = "";
        if (content.contains("name"))
        {
            name = content.get<string>("name");
        }
        var stages = db_driver.get_stages(order, name);

        var res_stages = new List<dentity>();
        dentity stage_info = null;
        List<dentity> attrs = null;
        long prev_id = 0;
        foreach (var stage in stages)
        {
            var sid = stage.get<long>("stageid");
            if (sid != prev_id)
            {
                if (prev_id != 0)
                {
                    res_stages.Add(stage_info);
                }
                attrs = new List<dentity>();
                stage_info = new dentity();
                stage_info["stage_id"] = stage.get<long>("stageid");
                stage_info["order"] = stage.get<long>("documentid");
                stage_info["name"] = stage.get<string>("stagename");
                stage_info["result"] = stage.get<string>("stageresult");
                stage_info["performer"] = stage.get<string>("performer");
                stage_info["date_time"] = stage.get<long>("stagedate");
                stage_info["details"] = stage.get<string>("stagedetails", "");
                stage_info["attributes"] = attrs;

                prev_id = sid;
            }
            if (!stage.get("attrpath", "").is_null_or_empty())
            {
                var attr = new dentity();
                attr["name"] = stage.get("attrpath", "");
                attr["value"] = stage.get("attrvalue", "");
                attrs.Add(attr);
            }
        }
        if (stage_info != null)
        {
            res_stages.Add(stage_info);
        }
        var res = new dentity();
        res["stages"] = res_stages;
        result(res);
        /*
    dp.stageid, 
    dp.documentid, 
    dp.stagedate, 
    dp.performer, 
    dp.stagename,
    dp.stageresult, 
    dp.stagedetails, 
    dp.extraresult, 
    dp.extradetails,
    dpa.attrpath,
    dpa.attrvalue
         */
    }
    public static void attach_document(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.soz_driver[contour];
            var order_id = content.get<long>("order");
            var name = content.get<string>("document_name");
            driver.attach_document(order_id, name);
            result(new dentity());
        }
        catch (Exception e)
        {
            error(e);
        }

    }
    #endregion
    #region state
    public static void set_state(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var wss_driver = s.soz_wss_driver[contour];
            var order = content.get<long>("order");
            var state = content.get<string>("state");
            var request = wss_driver.set_state(order, state);
            var responce = wss_driver.send_request(request);

            var d = handle_response(responce);
            var r = d.xml()
                    .Element("BODY")
                    .Element("Result").Value;

            if (r.Equals("Ok"))
            {
                result(new dentity());
            }
            else
            {
                error(new Exception("не удалось установить состояние \"{0}\"".format(state)));
            }
        }
        catch (Exception e)
        {
            error(e);
        }
    }

    private static string handle_response(string responce)
    {
        XNamespace ns = "http://schemas.xmlsoap.org/soap/envelope/";
        XNamespace ns2 = "http://support.diasoft.ru";
        var doc = responce.xml();
        var res = new dentity();

        if (responce.Trim().is_null_or_empty())
        {
            throw new Exception("сервис СОЗа вернул пустое сообщение");
        }
        if (responce.Contains("commandresult"))
        {
            return doc
                    .Element(ns + "Envelope")
                    .Element(ns + "Body")
                    .Element(ns2 + "DSCALLRESPONSE")
                    .Element(ns2 + "commandresult")
                    .Value;
        }
        else if (responce.Contains("DSCALLFAULT"))
        {
            var rt = doc
                    .Element(ns + "Envelope")
                    .Element(ns + "Body")
                    .Element(ns + "Fault")
                    .Element("faultstring").Value;
            throw new Exception("ошибка на сервисе СОЗа: \"{0}\"".format(rt));
        }
        throw new Exception("от сервиса вернулся ответ неизвестного формата");
    }
    #endregion
    #endregion
    #region metodix
    public static void upload_crd_file(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (! s.mx_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.mx_driver[contour];
            long order_id = content.get<long>("order");
            var directory = content.get<string>("directory");
            var path = driver.get_crd_file(order_id, directory);
            var res = new dentity();
            if (path.is_null_or_empty())
            {
                error(new Exception("не найден файл для выгрузки"));
            }
            else
            {
                res["path"] = path;
                result(res);
            }
        }
        catch (Exception e)
        {
            error(e);
        }
    }
    public static void close_task(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (! s.mx_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.mx_driver[contour];
            long order_id = content.get<long>("order");
            driver.close_task(order_id);
            var res = new dentity();
            result(res);
        }
        catch(Exception e)
        {
            error(e);
        }
    }
    public static void delete_client_from_buffer(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");
            if (!s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.mx_driver[contour];
            var order = content.get<long>("order");
            driver.delete_client_from_buffer(order);
            result(null);
        }
        catch (Exception e)
        {
            error(new Exception("при удалении клиента из буфера: \"{0}\"".format(e.Message)));
        }
    }
    #endregion
    #region product
    public static void get_products(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var contour = content.get<string>("contour");

            if (! s.soz_driver.ContainsKey(contour))
            {
                error(new Exception("контур \"{0}\" не определен".format(contour)));
            }
            var driver = s.soz_driver[contour];
            var a = content.get<List<object>>("attributes");
            var attrs = new Dictionary<string, string>();
            dentity attr;
            foreach (var item in a)
            {
                attr = (dentity)item;
                attrs.Add(attr.get<string>("name"), attr.get<string>("value"));
            }
            int type = content.get<int>("type");
            var prs = new List<dentity>();
            var resp = new dentity();
            if (type == 26 || type == 23)
            {
                var ps = driver.get_card_product(
                type,
                attrs.ContainsKey("Product_TarifPlan") ? attrs["Product_TarifPlan"] : "",
                attrs.ContainsKey("Product_Tariff") ? attrs["Product_Tariff"] : "",
                attrs.ContainsKey("Product_Currency") ? attrs["Product_Currency"] : "",
                attrs.ContainsKey("Product_CardType") ? attrs["Product_CardType"] : "",
                attrs.ContainsKey("Product_CardDesign") ? attrs["Product_CardDesign"] : "",
                attrs.ContainsKey("Product_CardParamText") ? attrs["Product_CardParamText"] : "",
                attrs.ContainsKey("Product_ActionText") ? attrs["Product_ActionText"] : "",
                attrs.ContainsKey("Product_Segment") ? attrs["Product_Segment"] : ""
                );
                foreach (var p in ps)
                {
                    var prod = new dentity();
                    prod["id"] = p.get<string>("id");
                    prod["type"] = type;
                    prod["card"] = p.get<string>("cardname");
                    prod["tariff"] = p.get<string>("tariff");
                    prod["currency"] = p.get<string>("currency");
                    prod["max_rate"] = p.get<string>("maxrate");
                    prod["min_rate"] = p.get<string>("minrate");
                    prod["min_amount"] = p.get<string>("minamount");
                    prod["max_amount"] = p.get<string>("maxamount");
                    prod["term"] = p.get<string>("term");
                    prod["action"] = p.get<string>("actionname");
                    prod["param"] = p.get<string>("paramname");
                    prod["design"] = p.get<string>("designname");
                    prod["tariff_plan"] = p.get<string>("tarifplanname");
                    prod["code_3card"] = p.get<string>("code3cres");
                    prod["group_3card"] = p.get<string>("grpcode3c");
                    prod["segment"] = p.get<string>("segmentname");
                    prod["is_obsolete"] = p.get<string>("isobsolete", "");
                    prs.Add(prod);
                }
            }
            else if (type == 13)
            {
                var ps = driver.get_cash_product();
                foreach (var p in ps)
                {
                    var prod = new dentity();
                    prod["id"] = p.get<long>("id");
                    prod["type"] = 13;
                    prod["name"] = p.get<string>("name");
                    prod["is_obsolete"] = p.get<string>("status") == "ACTIVE"?"": "BLOCKED";
                    prod["min_amount"] = p.get<string>("min_amount");
                    prod["max_amount"] = p.get<string>("max_amount");
                    prod["min_term"] = p.get<string>("min_term");
                    prod["max_term"] = p.get<string>("max_term");
                    prod["currency"] = p.get<string>("currency");
                    prod["code_3card"] = p.get<string>("code_3card");
                    prod["rate"] = p.get<string>("rate");
                    prod["min_man_age"] = p.get<string>("min_man_age");
                    prod["max_man_age"] = p.get<string>("max_man_age");
                    prod["min_woman_age"] = p.get<string>("min_woman_age");
                    prod["max_woman_age"] = p.get<string>("max_woman_age");
                    prs.Add(prod);
                }
            }
            else
            {
                error(new Exception("продукты для типа {0} не определены".format(type)));
            }
            resp["products"] = prs;
            result(resp);
        }
        catch (Exception e)
        {
            error(e);
        }
    }
    public static void get_attributes(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            if (!content.contains("type"))
            {
                error(new Exception("не указан тип продукта"));
            }
            var type = content.get<int>("type");

            var attrs = new List<dentity>(s.card_value.Count);
            dentity attr = null;

            Dictionary<string, string> values = null;
            Dictionary<string, int> types = null;

            if (type == 23 || type == 26)
            {
                values = s.card_value;
                types = s.card_type;
            }
            else
            {
                values = s.cash_value;
                types = s.cash_type;
            }
            foreach (var a in values)
            {
                attr = new dentity();
                attr["name"] = a.Key;
                attr["value"] = a.Value;
                attr["type"] = types[a.Key];
                attrs.Add(attr);
            }
            var r = new dentity();
            r["attributes"] = attrs;
            result(r);
        }
        catch (Exception ex)
        {
            error(ex);
        }
    }
    #endregion
    #region contour
    public static void ping(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            var r = new dentity();
            if (content.contains("contour"))
            {
                var contour = content.get<string>("contour");
                if (!s.soz_driver.ContainsKey(contour))
                {
                    error(new Exception("контур \"{0}\" не определен".format(contour)));
                }
                var systems = content.get<List<Object>>("systems");
                var pr = new List<dentity>();
                string details = "";
                bool status;
                foreach (var system in systems)
                {
                    status = false;
                    var row = new dentity();
                    row["system"] = system.ToString();
                    switch (system.ToString())
                    {
                        case "soz_db":
                            {
                                var db = s.soz_driver[contour];
                                status = db.ping(out details);
                            }
                            break;
                        case "wss":
                            {
                                var wss = s.soz_wss_driver[contour];
                                status = wss.ping(out details);
                            }
                            break;
                        case "mx_db":
                            {
                                var db = s.mx_driver[contour];
                                status = db.ping(out details);
                            }
                            break;
                    }
                    row["status"] = (status) ? "online" : "offline";
                    row["details"] = details;
                    pr.Add(row);
                }
                r["systems"] = pr;
            }
            else
            {
                r["pong"] = "ok"; 
            }
            result(r);
        }
        catch (Exception e)
        {
            error(new Exception("ошибка при проверке доступности систем:\"{0}\"".format(e.Message)));
        }
         
    }

    #endregion
    #region template
    public static void get_template(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            int type = content.get<int>("type");
            var b = s.db.get_template(type, initiator);

            // сделать условие выборки по id

            var tmps = new List<dentity>();
            dentity tmp = null;
            foreach (var t in b)
            {
                int template_id = t.get<int>("id");

                tmp = new dentity();
                tmp["id"] = template_id;
                tmp["name"] = t.get<string>("name");
                tmp["type"] = t.get<string>("type");
                tmp["description"] = t.get<string>("description");
                // подгрузить атрибуты шаблона
                var a = s.db.get_template_attribute(template_id);
                var attrs = new List<dentity>();
                dentity attr = null;
                foreach (var row in a)
                {
                    attr = new dentity();
                    attr["name"] = row.get<string>("name");
                    attr["value"] = row.get<string>("value");
                    attrs.Add(attr);
                }
                tmps.Add(tmp);
                tmp["attributes"] = attrs;
            }


            var r = new dentity();
            r["templates"] = tmps;
            result(r);
        }
        catch (Exception e)
        {
            error(new Exception("ошибка при проверке доступности систем:\"{0}\"".format(e.Message)));
        }

    }

    public static void save_template(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            int type = content.get<int>("type");
            string name = content.get<string>("name");
            string description = content.get<string>("description");
            var a = content.get<List<dynamic>>("attributes");
            var attrs = new bundle("name", "value");
            foreach (var it in a)
            {
                attrs.add(it.get<string>("name"), it.get<string>("value"));
            }
            int id = -1; 
            if (content.contains("id"))
            {
                id = content.get<int>("id");
                s.db.update_template(id, type, name, description, initiator, attrs);
            }
            else
            {
                id = s.db.create_template(type, name, description, initiator, attrs);
            }
            var r = new dentity();
            r["id"] = id;
            result(r);
        }
        catch (Exception ex)
        {
            error(new Exception("ошибка при добавлении нового шаблона:\"{0}\"".format(ex.Message)));
        }
    }

    public static void delete_template(string initiator, string context, string action, dentity content, Action<dentity> result, Action<Exception> error)
    {
        try
        {
            int id = content.get<int>("id");
            s.db.delete_template(id);
            result(null);
        }
        catch (Exception ex)
        {
            error(new Exception("при удалении шаблона :\"{0}\"".format(ex.Message)));
        }
    }
    #endregion
}