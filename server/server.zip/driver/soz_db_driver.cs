﻿using jeyjen.db;
using jeyjen.extension;
using System;
using System.Collections.Generic;
using System.Text;

namespace server.driver
{
    public class soz_db_driver
    {
        connection _con;
        public soz_db_driver(string cs)
        {
            _con = new connection(provider.oracle, cs, 120);
        }

        public bundle get_order(long order_id)
        {
            var query = @"
select 
    documentid, 
    documenttype, 
    documentnumber, 
    creationdate,
    createdby, 
    state, 
    ext1date, 
    ext2date, 
    ext3date,
    ext4date, 
    ext5date, 
    string1, 
    string2, 
    string3,
    string4, 
    string5, 
    int1, 
    int2, 
    int3, 
    int4, 
    int5,
    amount1, 
    amount2, 
    amount3, 
    amount4, 
    amount5 
from 
    doc_document
where 
    documentid = :order_id";

            return _con.cmd(query)
                .param("order_id", order_id)
                .retrieve();
        }

        public string get_attribute_value(long order, string attr)
        {
            var query = @"
select 
    attrvalue
from 
    doc_docattribute 
where 
    documentid = :order_id
    and attrpath = :name
";
            return _con.cmd(query)
                .param("order_id", order)
                .param("name", "/root/" + attr)
                .scalar<string>();
        }

        public bundle get_attributes(long order_id, List<string> attrs = null)
        {
            var query = @"
select 
    documentid, 
    docattributeid, 
    attrnumber, 
    parentid,   
    attrpath, 
    attrtype, 
    attrcount, 
    attrvalue, 
    attrvaluetext 
from 
    doc_docattribute 
where 
    documentid = :order_id
    $attrs_condition$
             order by attrpath";
            var con = "";
            if (attrs != null && attrs.Count > 0)
            {
                var sb = new StringBuilder();
                sb.AppendFormat("and attrpath in ('/root/{0}'", attrs[0]);
                for (int i = 1; i < attrs.Count; i++)
                {
                    sb.AppendFormat(", '/root/{0}'", attrs[i]);
                }
                sb.Append(')');
                con = sb.ToString();
            }
            query = query
                .param("attrs_condition", con);

            return _con.cmd(query)
                .param("order_id", order_id)
                .retrieve();
        }
        public bundle get_card_product(int type, string tariff_plan, string tariff, string currency, string card, string design, string card_param, string action, string segment)
        {
            #region query
            string query = @"
select
  cs.settingid as id,
  ct.cardname,    
  rc.alphacode as currency,   
  ctt.typeid as tariffid,     
  ctt.tarifname as tariff,    
  cs.minrate,    
  cs.maxrate,    
  cs.minamount,   
  cs.maxamount,    
  ctt.term,   
  cs.isinstantissue,   
  ca.actionid,   
  ca.actionname,    
  cp.paramid,   
  cp.paramname,    
  cd.designname,    
  cs.month_free,   
  ctt.isrbp,   
  ctt.defaultpintype,   
  tp.tarifplanname,   
  cs.code3cres,   
  cs.grpcode3c,   
  seg.segmentname,
  case when sysdate not between cs.startdate and cs.enddate then 'настройки'
    when sysdate not between ct.startdate and ct.enddate then 'карта'
    when sysdate not between ctt.startdate and ctt.enddate then 'тариф'
    when sysdate not between cp.startdate and cp.enddate then 'параметры'
    when sysdate not between cd.startdate and cd.enddate then 'дизайн'
    when sysdate not between tp.startdate and tp.enddate then 'тарифный план'
    when sysdate not between seg.startdate and seg.enddate then 'сегмент'
    when sysdate not between ca.startdate and ca.enddate then 'акция'
    else null
  end isobsolete
from 
    t_cardsettings cs
join t_cardtype ct on cs.cardtypeid=ct.typeid
join ref_currency rc on cs.currencyid=rc.currencyid
join t_cardtariftype ctt on cs.tariftypeid=ctt.typeid
left join t_cardtarifplan tp on cs.tarifplanid = tp.tarifplanid
left join t_card_segment_settings cssg on cs.settingid = cssg.settingid
left join t_cardsegment seg on cssg.segmentid = seg.segmentid
left join t_cardaction ca on cs.actionid=ca.actionid
left join t_cardparam cp on cs.paramid=cp.paramid
left join t_carddesign cd on cs.designid=cd.designid 
where 
  1=1
  $condition$
order by
  tp.tarifplanname asc,
  ctt.tarifname asc,
  rc.alphacode asc,
  ct.cardname asc,
  cd.designname asc
";
            #endregion

            StringBuilder cond = new StringBuilder();
            cond.AppendFormat("\r\nand cs.doctypeid = {0}", type);
            if (! tariff_plan.is_empty())
            {
                if (tariff_plan.is_null())
                {
                    cond.Append("\r\nand tp.tarifplanname is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand tp.tarifplanname = '{0}'", tariff_plan);
                }
            }
            if (! tariff.is_empty())
            {
                if (tariff.is_null())
                {
                    cond.Append("\r\nand ctt.tarifname is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand ctt.tarifname = '{0}'", tariff);
                }
            }
            if (! currency.is_empty())
            {
                if (currency.is_null())
                {
                    cond.Append("\r\nand rc.alphacode is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand rc.alphacode = '{0}'", currency);
                }
            }
            if (! card.is_empty())
            {
                if (card.is_null())
                {
                    cond.Append("\r\nand ct.cardname is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand ct.cardname = '{0}'", card);
                }
            }

            if (! design.is_empty())
            {
                if (design.is_null())
                {
                    cond.Append("\r\nand cd.designname is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand cd.designname = '{0}'", design);
                }
            }
            if (! card_param.is_empty())
            {
                if (card_param.is_null())
                {
                    cond.Append("\r\nand cp.paramname is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand cp.paramname = '{0}'", card_param);
                }
            }
            
            if (! action.is_empty())
            {
                if (action.is_null())
                {
                    cond.Append("\r\nand ca.actionname is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand ca.actionname = '{0}'", action);
                }
            }
            if (! segment.is_empty())
            {
                if (segment.is_null())
                {
                    cond.Append("\r\nand seg.segmentname is null");
                }
                else
                {
                    cond.AppendFormat("\r\nand seg.segmentname = '{0}'", segment);
                }
            }
            string result_query = query.param("condition", cond.ToString());
            return _con.cmd(result_query)
                .retrieve();
        }
        public bundle get_cash_product_details(long product_id)
        {
            const string query = @"
select 
  pc.productname,
  pc.amount_min as minamount,
  pc.amount_max as maxamount,
  pc.periodmonth_min as minterm,
  pc.periodmonth_max as maxterm,
  pc.currency
from cash_product_catalog pc
where
  pc.productid = :product_id
";
            return _con.cmd(query)
                .param("product_id", product_id)
                .retrieve();
        }

        public bundle get_privilege_rate(string param_name, string product_name)
        {
            string query = @"
select  
    c.paramtype, 
    d.value1  
from 
    prd_product a
join 
    prd_productgroup b 
on 
    b.productgroupid = a.productgroupid
join 
    prd_param c 
on 
    a.productid = c.productid
join 
    prd_paramvalue d 
on 
    c.paramid = d.paramid 
where 
  NVL(a.validto +TO_DATE('30.12.1899 00:00:00','DD.MM.YYYY HH24:MI:SS'),SYSDATE+1)> SYSDATE
  and a.productname = :product
  and c.paramtype = :par 
  and a.status = 'ACTIVE'
order by a.productname
";

            return _con.cmd(query)
                .param("par", param_name)
                .param("product", product_name)
                .retrieve();
        }

        public bundle get_sale_channel()
        {
            string query = @"
select 
    channelname 
from 
    dep_salechannel 
order by 
    channelname";

            return _con.cmd(query)
                .retrieve();
        }

        public bundle get_product_info_source()
        {
            string query = @"
select 
    refitem.code,
    refitem.shortvalue
from 
    ref_refitem refitem
inner join 
    ref_reference refref 
on 
    refitem.referenceid = refref.referenceid 
inner join 
    ref_referencegroup refgroup 
on 
    refgroup.referencegroupid = refref.referencegroup 
where 
    refgroup.groupname = 'Справочник источников информации о Банке' 
    and refref.referencename = 'Источник информации о Банке'
    and shortvalue != '000'
order by 
    shortvalue";

            return _con.cmd(query)
                .retrieve();
        }

        public bundle get_product_name_by_id(int program_id)
        {

            string query = @"
select 
    prod.productname 
from 
    prd_product prod 
where 
    prod.productid = :program_id";

            return _con.cmd(query)
                .param("program_id", program_id)
                .retrieve();
        }

        public bundle get_id_by_product_name(string name)
        {
            string query = @"
select 
    prod.productid
from 
    prd_product prod 
where 
    prod.productname = :name";

            return _con.cmd(query)
                .param("name", name)
                .retrieve();
        }

        public bundle get_cash_product(long? product_id = null)
        {
            var query = @"
select 
  prod.productid as id,
  prod.productname as name,
  prod.status,
  pc.amount_min as min_amount,
  pc.amount_max as max_amount,
  pc.periodmonth_min as min_term,
  pc.periodmonth_max as max_term,
  pc.currency,
  pc.upload3cardrcode as code_3card,
  pc.rate,
  pc.manage_min as min_man_age,
  pc.manage_max as max_man_age,
  pc.womanage_min as min_woman_age,
  pc.womanage_max as max_woman_age
from 
  cash_product_catalog pc
right join 
  prd_product prod
on 
  prod.productid = pc.productid
join 
  prd_productgroup pp
on 
  pp.productgroupid = prod.productgroupid
where
 pp.groupname = 'Cash'
 $product$";

            var cond = product_id == null ? "" : "and prod.productid = {0}".format(product_id);
            query = query.param("product", cond);
            return _con.cmd(query)
                .retrieve();
        }

        public bundle get_stages(long order_id, string name = "")
        {
            var query = @"
select 
    dp.stageid, 
    dp.documentid, 
    dp.stagedate, 
    dp.performer, 
    dp.stagename,
    dp.stageresult, 
    cast(dp.stagedetails as varchar2(500)) as stagedetails,
    dp.extraresult, 
    cast(dp.extradetails as varchar2(500)) as extradetails,    
    dpa.attrpath,
    dpa.attrvalue
from 
    doc_docprocessing dp
left join 
    doc_procattribute dpa
on
    dpa.stageid = dp.stageid
    and dpa.attrpath != '/root'
where 
    dp.documentid = :order_id
    $name_condiction$
order by stageid";

            connection.command cmd = null;

            if (!name.is_null_or_empty())
            {
                query = query
                    .param("name_condiction", "and dp.stagename = :stage_name");

                cmd = _con.cmd(query)
                    .param("order_id", order_id)
                    .param("stage_name", name);

            }
            else
            {
                query = query
                    .param("name_condiction", "");

                cmd = _con.cmd(query)
                    .param("order_id", order_id);
            }

            return cmd.retrieve();
        }
        public int get_type_by_id(long order_id)
        {
            var query = @"
select 
    dd.documenttype 
from 
    doc_document dd 
where 
    dd.documentid = :order_id
";
            return _con.cmd(query)
                .param("order_id", order_id)
                .scalar<int>();
        }

        public void attach_document(long order_id, string doc_name)
        {
            string query = @"
insert into doc_attachment
    (
        attachmentid,
        documentid,
        attdoctype,
        contenttype,
        attname,
        attdocname,
        attfilepath,
        attsize,
        creator,
        creationdate
    ) 
values
    (
        :id,
        :order_id,
        (select attachtypeid from doc_attachtype where name=:name and rownum=1),
        'image/pjpeg',
        'NNNNNN_PHOTO_Familia IO.jpg',
        '',
        1,
        631,
        'robotest',
        40000
    )
";
            var id = get_new_id("DOC_ATTACHMENT", 1);
            _con.cmd(query)
                .param("id", id)
                .param("order_id", order_id)
                .param("name", doc_name)
                .execute();
        }

        public long get_new_id(string table_name, int count = 1)
        {
            #region get pk column query
            string get_pk_query = @"
select distinct 
    cols.column_name 
from 
    all_constraints cons, 
    all_cons_columns cols 
where 
    cols.table_name = :table_name 
    and cons.constraint_type = 'P' 
    and cons.constraint_name = cols.constraint_name  
    and cons.owner = cols.owner";
            #endregion

            var column_name = _con.cmd(get_pk_query)
                .param("table_name", table_name)
                .scalar<string>();
            long id = 0;
            var check_query = @"
select 
    $column$ 
from 
    $table$ 
where 
    :down <= $column$ 
    and $column$ < :up"
.param("column", column_name)
.param("table", table_name);

            var new_id_query = @"
select 
    sozc.auto_nextid(:table_name, :count) as id 
from 
    dual";

            for (int i = 0; i < 10; i++)
            {
                var t_id = _con.cmd(new_id_query)
                    .param("table_name", table_name)
                    .param("count", count)
                    .scalar<long>();

                var ids = _con.cmd(check_query)
                    .param("down", id)
                    .param("up", id + count)
                    .retrieve();
                if (ids.count == 0)
                {
                    id = t_id;
                    break;
                }
            }

            if (id == 0)
            {
                throw new Exception("не удалось получить уникального id для таблицы \"{0}\"".format(table_name));
            }
            return id;
        }

        #region card
        public bundle get_cards(long card_id)
        {
            var query = @"
select 
    externalid,
    status,
    cardnumber,
    addnumber,
    date_ftod_tz(expirationdate) as expirationdate,
    participantid,
    productid,
    cardtypeid,
    currencyid,
    limit,
    codeword,
    ismaincard,
    maincardid,
    uploadflag
from crd_card cc 
where 
    cc.externalid = :id";
            return _con.cmd(query)
                .param("id", card_id)
                .retrieve();
        }
        #endregion

        #region handbook

        public bundle get_handbook_of(string group, string name)
        {
             
            string query = @"
select 
    shortvalue, 
    code,
    groupname,
    referencename                      
from ref_refitem 
inner join 
    ref_reference 
on 
    ref_refitem.Referenceid = ref_reference.Referenceid 
Inner join 
    ref_referencegroup 
on 
    ref_referencegroup.Referencegroupid = ref_reference.Referencegroup
where 
    groupname = :gr 
    and referencename = :nm
";
            return _con.cmd(query)
                .param("gr", group)
                .param("nm", name)
                .retrieve();
        }

        public bundle get_employers()
        {
             
            string query = @"
select 
    id, 
    name 
from 
    t_salary_clients
where
    rownum <= 20
";
            return _con.cmd(query)
                .retrieve();
        }

        public bundle get_filials(int region)
        {
             
            string query = @"
select 
    spname 
from 
    dep_salepoint 
where 
    isvalid = 1
    and coderegion = :region
";
            return _con.cmd(query)
                .param("region", region)
                .retrieve();
        }

        public bundle get_position_list(string card_type)
        {
             
            string query = @"
select 
    broker 
from 
    sprrbr_itemspr 
where 
    var1 = :p1 
    and idgroup = 52
";
            return _con.cmd(query)
                .param("p1", card_type)
                .retrieve();
        }
        #endregion

        #region query

        #region document/insert
        public const string InsertDocDocument = @"
insert into doc_document 
(
    documentid,
    documenttype,
    documentnumber,
    creationdate, 
    createdby,
    state,
    ext1date,
    ext2date,
    ext3date,
    ext4date,
    ext5date,
    string1,
    string2,
    string3,
    string4,
    string5,
    int1,
    int2,
    int3,
    int4,
    int5,
    amount1,
    amount2,
    amount3,
    amount4,
    amount5
)
values
(
    :docId, 
    :docType, 
    :docNum, 
    date_dtof_tz(:creationdate),
    :createdby, 
    :state, 
    :ext1date, 
    :ext2date, 
    :ext3date, 
    :ext4date, 
    :ext5date, 
    :string1, 
    :string2,
    :string3, 
    :string4, 
    :string5, 
    :int1, 
    :int2, 
    :int3, 
    :int4, 
    :int5, 
    :amount1, 
    :amount2, 
    :amount3, 
    :amount4, 
    :amount5
)
";
        #endregion
        #region document/update
        internal const string UpdateOrderState = @"
update doc_document 
set 
    state = :state
where 
documentid = :documentid
";
        #endregion
        #region document/select
        public const string SelectDocDocumentById = @"
select 
    documentid, 
    documenttype, 
    documentnumber, 
    creationdate,
    createdby, 
    state, 
    ext1date, 
    ext2date, 
    ext3date,
    ext4date, 
    ext5date, 
    string1, 
    string2, 
    string3,
    string4, 
    string5, 
    int1, 
    int2, 
    int3, 
    int4, 
    int5,
    amount1, 
    amount2, 
    amount3, 
    amount4, 
    amount5 
from 
    doc_document
where 
    documentid = :docid
";
        #endregion

        #region documentext/select
        public const string SelectDocumentExt = @"
select 
    documentid, 
    lastname, 
    firstname, 
    middlename, 
    ubcity, 
    creator, 
    documenttype, 
    tarif, 
    passport_series, 
    passport_number, 
    snils, 
    addinfobank_receiveinbranch, 
    addinfobank_applyedinbranch,
    cloneid,
    qa_extflt,
    cardid,
    birthdate,
    dx_saveorder_rqid,
    addinfobank_filial,
    addinfobank_entredinbranch  
from 
    doc_documentext
where 
    documentid = :docid
";
        #endregion
        #region documentext/insert
        public const string InsertDocumentExt = @"
insert into doc_documentext 
(
    documentid, 
    lastname, 
    firstname, 
    middlename, 
    ubcity, 
    creator, 
    documenttype, 
    tarif, 
    passport_series, 
    passport_number, 
    snils, 
    addinfobank_receiveinbranch, 
    addinfobank_applyedinbranch,
    cloneid,
    qa_extflt,
    cardid,
    birthdate,
    dx_saveorder_rqid,
    addinfobank_filial,
    addinfobank_entredinbranch
) values 
(
    :documentid, 
    :lastname, 
    :firstname, 
    :middlename, 
    :ubcity, 
    :creator, 
    :documenttype, 
    :tarif, 
    :passport_series, 
    :passport_number, 
    :snils, 
    :addinfobank_receiveinbranch, 
    :addinfobank_applyedinbranch,
    :cloneid,
    :qa_extflt,
    :cardid,
    :birthdate,
    :dx_saveorder_rqid,
    :addinfobank_filial,
    :addinfobank_entredinbranch
)";
        #endregion


        #region crm_participant/select
        public const string SelectCrmParticipant = @"
select distinct 
    cp.participantid, 
    cp.externalid, 
    cp.participanttype, 
    cp.isclient, 
    cp.state, 
    cp.creationdate 
from 
    crm_participant cp 
join
    doc_docparticipant dd 
on 
    cp.participantid = dd.participantid
where 
    dd.documentid = :docid
";
        #endregion
        #region crm_participant/insert
        internal const string InsertCrmParticipant = @"
insert into crm_participant 
(
    participantid, 
    externalid, 
    participanttype, 
    isclient, 
    state, 
    creationdate
)
values 
(
    :participantid, 
    :externalid, 
    :participanttype, 
    :isclient, 
    :state, 
    date_dtof_tz(:creationdate)
)
";
        #endregion


        #region docparticipant/select
        public const string SelectDocDocparticipant = @"
select distinct 
    docparticipantid, 
    documentid, 
    participantid, 
    linktype
from 
    doc_docparticipant 
where 
    documentid = :docid";
        #endregion
        #region docparticipant/insert
        internal const string InsertDocParticipant = @"
insert into doc_docparticipant 
(
    docparticipantid, 
    documentid, 
    participantid, 
    linktype
)
values 
(
    :docparticipantid, 
    :documentid, 
    :participantid, 
    :linktype
)";
        #endregion


        #region crm_person/select
        public const string SelectCrmPerson = @"
select distinct 
    cp.participantid, 
    personid, 
    firstname, 
    middlename, 
    lastname,   
    engfirstname, 
    englastname, 
    birthdate,
    birthplace, 
    gender, 
    citizenship, 
    isresident, 
    istaxresident, 
    inn, 
    isbusinessman, 
    egrn, 
    egrip
from 
    crm_person cp 
join 
    doc_docparticipant dd 
on 
    cp.participantid = dd.participantid 
where 
    dd.documentid = :docid";
        #endregion
        #region crm_person/insert
        internal const string InsertCrmPerson = @"
insert into crm_person 
(
    participantid, 
    personid, 
    firstname, 
    middlename, 
    lastname, 
    engfirstname, 
    englastname, 
    birthdate,
    birthplace, 
    gender, 
    citizenship, 
    isresident, 
    istaxresident, 
    inn, 
    isbusinessman, 
    egrn, 
    egrip
)
values 
(
    :participantid, 
    :personid, 
    :firstname, 
    :middlename, 
    :lastname, 
    :engfirstname,     
    :englastname, 
    date_dtof_tz(:birthdate), 
    :birthplace, 
    :gender, 
    :citizenship, 
    :isresident, 
    :istaxresident, 
    :inn, 
    :isbusinessman, 
    :egrn, 
    :egrip
)";
        #endregion

        #region crm_persondoc/insert
        internal const string InsertCrmPersonDoc = @"
insert into crm_persondoc 
(
    persondocid, 
    personid, 
    doctypeid, 
    docseries, 
    docnumber, 
    issuedate, 
    issuedby, 
    issuercode, 
    validto, 
    ismaindoc
)
values 
(
    :persondocid, 
    :personid, 
    :doctypeid, 
    :docseries, 
    :docnumber, 
    date_dtof_tz(:issuedate), 
    :issuedby, 
    :issuercode, 
    date_dtof_tz(:validto),
    :ismaindoc
)
";
        #endregion

        #region docprocessing /select

        #endregion
        #region docprocessing /insert_all
        internal const string InsertDocProcessing = @"
insert into 
    doc_docprocessing 
(
    stageid, 
    documentid, 
    stagedate, 
    performer, 
    stagename,
    stageresult, 
    stagedetails, 
    extraresult, 
    extradetails  
)
values
(
    :stageid, 
    :documentid,
    date_dtof_tz(:stagedate),
    :performer, 
    :stagename, 
    :stageresult, 
    :stagedetails, 
    :extraresult,
    :extradetails
)
";
        internal const string InsertDocProcessingOriginDate = @"
insert into 
    doc_docprocessing 
(
    stageid, 
    documentid, 
    stagedate, 
    performer, 
    stagename,
    stageresult, 
    stagedetails, 
    extraresult, 
    extradetails  
)
values
(
    :stageid, 
    :documentid,
    :stagedate,
    :performer, 
    :stagename, 
    :stageresult, 
    :stagedetails, 
    :extraresult,
    :extradetails
)
";

        public bool ping(out string details)
        {
            details = "";
            var query = @"
select 
    *
from
    doc_document
where
    rownum <= 1";

            try
            {
                _con.cmd(query)
                    .retrieve();
                return true;
            }
            catch (Exception e)
            {
                details = e.Message;
                return false;
            }
        }
        #endregion
        #region docprocessing /update
        public const string UpdateDocProcessing = @"
update 
    doc_docprocessing 
set 
    performer = :performer, 
    stageresult = :stageresult 
where 
    documentid = :order_id
    and stagename = :name
"
;
        #endregion

        #region procattribute/select
        public const string SelectDocProcattribute = @"
select 
    procattributeid, 
    doc_procattribute.stageid, 
    attrnumber, 
    parentid, 
    attrpath, 
    attrtype, 
    attrcount, 
    attrvalue, 
    attrvaluetext
from 
    doc_procattribute 
join 
    doc_docprocessing
on 
    doc_procattribute.stageid = doc_docprocessing.stageid
where 
    doc_docprocessing.documentid = :docid
";
        #endregion
        #region procattribute/insert
        internal const string InsertProcAttribute = @"
insert into
    doc_procattribute 
(
    procattributeid, 
    stageid, 
    attrnumber, 
    parentid, 
    attrpath, 
    attrtype, 
    attrcount, 
    attrvalue, 
    attrvaluetext
)
values
( 
    :procattributeid, 
    :stageid, 
    :attrnumber, 
    :parentid,
    :attrpath, 
    :attrtype, 
    :attrcount, 
    :attrvalue, 
    :attrvaluetext
)
";
        #endregion
        #region procattribute/insert
        public const string InsertDocProcessingAttribute = @"
insert into 
    doc_procattribute 
    (
        procattributeid, 
        stageid, 
        attrnumber, 
        attrpath, 
        attrtype, 
        attrvalue
    )
    values 
    (
        :id, 
        (
            select 
                dp.stageid 
            from 
                doc_docprocessing dp 
            where 
                rownum = 1 
                and dp.documentid = :order_id 
                and dp.stagename = :step
        ),
      1,
      :attr,
    1,
      :value
    )
";
        #endregion

        #region doc_attachment/insert
        public const string InsertDocAttachment = @"
insert into doc_attachment
    (
        attachmentid,
        documentid,
        attdoctype,
        contenttype,
        attname,
        attdocname,
        attfilepath,
        attsize,
        creator,
        creationdate
    ) 
values
    (
        :id,
        :order_id,
        (select attachtypeid from doc_attachtype where name=:doc_name and rownum=1),
        'image/pjpeg',
        'NNNNNN_PHOTO_Familia IO.jpg',
        '',
        1,
        631,
        'robotest',
        40000
    )
";
        #endregion

        #region docattribute/select
        public const string SelectDocAttributeByDocumentId = @"
select 
    documentid, 
    docattributeid, 
    attrnumber, 
    parentid,   
    attrpath, 
    attrtype, 
    attrcount, 
    attrvalue, 
    attrvaluetext 
from 
    doc_docattribute 
where 
    documentid = :docid
             order by attrpath";
        #endregion
        #region docattribute/insert_all
        internal const string InsertDocAttribute =
@"insert into doc_docattribute 
(
    docattributeid, 
    documentid, 
    attrnumber, 
    parentid, 
    attrpath, 
    attrtype, 
    attrcount, 
    attrvalue, 
    attrvaluetext
) 
values 
( 
    :docattributeid, 
    :documentid, 
    :attrnumber, 
    :parentid, 
    :attrpath, 
    :attrtype, 
    :attrcount, 
    :attrvalue, 
    :attrvaluetext 
)
";
        #endregion


        #region new pk generation
        public const string GetPKColumnName = @"
select distinct 
    cols.column_name 
from 
    all_constraints cons, 
    all_cons_columns cols 
where 
    cols.table_name = :tab 
    and cons.constraint_type = 'P' 
    and cons.constraint_name = cols.constraint_name  
    and cons.owner = cols.owner";

        public const string NewID = @"SELECT sozc.auto_nextid(:tab, :count) as id from dual";

        internal const string CheckIfIdIsExists = "SELECT {0} FROM {1} WHERE :down <= {0} and {0} < :up";
        #endregion
        #region other data (handbooks)
        public const string GetFilials = @"
select 
    spname 
from 
    dep_salepoint 
where 
    isvalid = 1
    and coderegion = :region
";
        public const string GetEmployerName = @"
select 
    id, 
    name 
from 
    t_salary_clients
";

        public const string SelectUserSaleChannel = @"
select 
  b.sname as sname, b.scode as scode
from 
  getviewrefusersoz a
left join 
  sprrbr_salechan b 
on 
  b.scode = a.channel
where a.fio = :fio
";
        public const string GetPositionList = @"
select 
    broker 
from 
    sprrbr_itemspr 
where 
    var1 = :p1 
    and idgroup = 52
";
        public const string SelectSaleChannel = @"
select 
    channelname 
from 
    dep_salechannel 
order by 
    channelname";

        public const string SelectSourceOfMoney = @"
select 
    a.broker
from 
    sprrbr_itemspr a 
inner join 
    sprrbr_groupspr g
on 
    a.idgroup=g.idgroup 
where 
    g.namegroup='Источники происхождения денежных средств' 
order by 
    a.broker
";

        public const string SelectProductInfoSource = @"
select 
    refitem.code,
    refitem.shortvalue
from 
    ref_refitem refitem
inner join 
    ref_reference refref 
on 
    refitem.referenceid = refref.referenceid 
inner join 
    ref_referencegroup refgroup 
on 
    refgroup.referencegroupid = refref.referencegroup 
where 
    refgroup.groupname = 'Справочник источников информации о Банке' 
    and refref.referencename = 'Источник информации о Банке'
    and shortvalue != '000'
order by 
    shortvalue";
        public const string HanDbookData = @"
select 
    shortvalue, 
    code,
    groupname,
    referencename                      
from ref_refitem 
inner join 
    ref_reference 
on 
    ref_refitem.Referenceid = ref_reference.Referenceid 
Inner join 
    ref_referencegroup 
on 
    ref_referencegroup.Referencegroupid = ref_reference.Referencegroup
where 
    groupname = :gr 
    and referencename = :nm";

        public const string GetTariffsByPlan = @"
select distinct 
    ctt.typeid, 
    ctt.tarifname 
from 
    t_cardsettings cs 
join 
    t_cardtariftype ctt 
on 
    cs.tariftypeid = ctt.typeid 
where 
  (sysdate between cs.startdate and cs.enddate) 
  and (sysdate between ctt.startdate and ctt.enddate) 
  and cs.settingid not in (select distinct settingid from t_cardaccess where settingid is not null)
  and cs.tarifplanid = :tariff_plan
  order by ctt.tarifname
";

        public const string PeriodWithCurrentEmployer = @"
select 
    a.itemid, 
    a.idgroup, 
    a.broker, 
    a.fa#, 
    a.sas, 
    a.mx, 
    a.var1, 
    a.var2, 
    a.var3, 
    a.var4, 
    a.var5 
from 
    sprrbr_itemspr a 
where 
    idgroup in (47) 
    and var1 = 1";
        #endregion
        #region card info
        public const string CardInfo = @"
select 
  ct.cardname, 
  rc.alphacode as currency,
  ctt.typeid as tariffid,  
  ctt.tarifname as tariff, 
  cs.minrate, 
  cs.maxrate, 
  cs.minamount,
  cs.maxamount, 
  ctt.term,
  cs.isinstantissue,
  ca.actionid,
  ca.actionname, 
  cp.paramid,
  cp.paramname, 
  cd.designname, 
  cs.month_free,
  ctt.isrbp,
  ctt.defaultpintype,
  tp.tarifplanname,
  cs.code3cres,
  cs.grpcode3c,
  seg.segmentname
from t_cardsettings cs
  join t_cardtype ct on cs.cardtypeid=ct.typeid
  join ref_currency rc on cs.currencyid=rc.currencyid
  join t_cardtariftype ctt on cs.tariftypeid=ctt.typeid
  left join t_cardaction ca on cs.actionid=ca.actionid
  left join t_cardparam cp on cs.paramid=cp.paramid
  left join t_carddesign cd on cs.designid=cd.designid
  left join t_cardtarifplan tp on tp.tarifplanid = cs.tarifplanid
  left join t_card_segment_settings cssg on cs.settingid = cssg.settingid
  left join t_cardsegment seg on cssg.segmentid = seg.segmentid
where 
  (sysdate between cs.startdate and cs.enddate) 
  and (sysdate between ct.startdate and ct.enddate) 
  and (sysdate between ctt.startdate and ctt.enddate) 
  and (sysdate between cp.startdate and cp.enddate or cs.paramid is null) 
  and (sysdate between cd.startdate and cd.enddate or cs.designid is null) 
  {0}
  and cs.settingid not in (select distinct settingid from t_cardaccess where settingid is not null)
  order by Dbms_random.value
";
        #endregion
        #region cash product info
        public const string CashProductInfo = @"
select 
  pc.productname,
  pc.amount_min as minamount,
  pc.amount_max as maxamount,
  pc.periodmonth_min as minterm,
  pc.periodmonth_max as maxterm,
  pc.currency
from cash_product_catalog pc
where
  pc.productid = :productid
";
        #endregion
        #region get single value
        #region user info
        public const string GetUserFIO = @"
select 
    cp.lastname, 
    cp.firstname, 
    cp.middlename 
from 
    crm_person cp
where cp.participantid = 
(
    select participantid from core_user where userid = {0}
)
";
        internal const string GetFIOByUserId = @"
select 
    cp.lastname, 
    cp.firstname, 
    cp.middlename
from crm_person cp 
where 
    cp.participantid = 
    (
        select 
            participantid 
        from core_user
        where 
            userid = :userid)";
        public const string GetUserId = @"
select 
    cu.userid 
from 
    core_useraccount cu 
where 
cu.login = :login"; 
        #endregion

        public const string GetLimitListForRbp = @"
select 
    cast(broker as number) as limit 
from 
    sprrbr_itemspr
where 
    idgroup = 107
    and var1 = :currency
    and cast(broker as number) <= :amount
";
        public const string SelectPrivilegeRate = @"
select  
    c.paramtype, 
    d.value1  
from 
    prd_product a
join 
    prd_productgroup b 
on 
    b.productgroupid = a.productgroupid
join 
    prd_param c 
on 
    a.productid = c.productid
join 
    prd_paramvalue d 
on 
    c.paramid = d.paramid 
where 
  NVL(a.validto +TO_DATE('30.12.1899 00:00:00','DD.MM.YYYY HH24:MI:SS'),SYSDATE+1)> SYSDATE
  and a.productname = :product
  and c.paramtype = :par 
  and a.status = 'ACTIVE'
order by a.productname
";
        #endregion
        
        #region util
        public const string UpdateRootAtribute = @"
update 
    doc_docattribute 
set 
    attrnumber = 
    (
        select 
            count(*) 
        from 
            doc_docattribute 
        where 
            documentid = :docid
     ) 
where 
    documentid = :docid 
    and attrpath = '/root'";

        public const string SelectCrmPersondoc = @"
select distinct 
    cpd.persondocid, 
    cpd.personid, 
    cpd.doctypeid, 
    cpd.docseries, 
    cpd.docnumber, 
    cpd.issuedate, 
    cpd.issuedby, 
    cpd.issuercode, 
    cpd.validto, 
    cpd.ismaindoc
from 
    crm_person cp 
join 
    doc_docparticipant dd 
on 
    cp.participantid = dd.participantid
join 
    crm_persondoc cpd 
on 
    cpd.personid = cp.personid
where 
    dd.documentid = :docid";

        public const string DeleteDocDocattributeRootAttribute = @"
delete from     
    doc_docattribute 
where 
(
    attrpath='/root/DOCUMENTID' 
    or attrpath='/root/DOCUMENTNUMBER'
) 
and documentid=:docid
";
        #endregion
        #region trash
        public const string SelectDocumentIdFromDocDocument = @"
select 
    documentid 
from 
    doc_document
where 
    documentnumber = :docnumber       
";

        #endregion

       
        #endregion

    }
}
