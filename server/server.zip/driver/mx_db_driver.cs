﻿using jeyjen.db;
using jeyjen.extension;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace server.driver
{
    public class mx_db_driver
    {
        connection _con;
        public mx_db_driver(string cs)
        {
            _con = new connection(provider.sqlserver, cs, 120);
        }

        public string get_crd_file(long order_id, string directory)
        {
            var path = "";
            var res = _con
                .cmd("[AutoTest].[UP_Tibco_Get70]")
                .param("ID_SOZ", order_id.ToString())
                .out_param("Gate70Info", System.Data.DbType.Xml)
                .execute_procedure();

            if (res.ContainsKey("Gate70Info") && res["Gate70Info"] != null)
            {
                string file = res["Gate70Info"].ToString();

                if (!file.is_null_or_empty())
                {
                    var xml = file.xml().Element("Gate70");
                    var filename = xml.Element("Filename").Value;
                    var line = xml.Element("Line1").Value;
                    var body = xml.Element("FileBody").Value;
                    path = Path.Combine(directory, filename);
                    File.WriteAllText(path, line + Environment.NewLine + body, Encoding.GetEncoding("Windows-1251"));
                }
            }
            return path;
        }
        public void close_task(long order_id)
        {
            var res = _con
                .cmd("[AutoTest].[UP_Tibco_SOZtoUPI]")
                .param("id_Soz", order_id.ToString())
                .execute_procedure();
            /*
            var order_id = _context.Get<long>("order_id").ToString();
            using (SqlConnection conn = new SqlConnection(_context.Get<string>("mx_cs")))
            {
                using (SqlCommand cmd = new SqlCommand("[AutoTest].[UP_Tibco_SOZtoUPI]", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("id_Soz", SqlDbType.NVarChar, 10);
                    cmd.Parameters["id_Soz"].Value = order_id.ToString();
                    try
                    {
                        conn.Open();
                    }
                    catch (Exception e)
                    {
                        _log.Error("не удалось подключиться к БД Metodix: {0}", e.Message);
                        throw e;
                    }
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception e)
                    {
                        _log.Error("не удалось выполнить запрос к  Metodix: {0}", e.Message);
                        throw e;
                    }            
                }
            }
            */
        }

        public void delete_client_from_buffer(long order_id)
        {
            var query = @"
update 
    td_clients 
set 
    in_buffer = 0 
from 
    td_forms
where 
    td_clients.id_client = td_forms.id_client 
    and id_sourceform = :order";
            _con.cmd(query)
                .param("order", order_id)
                .execute();
        }
        #region query
        public const string GetClientDataFromMX = @"
SELECT top {0} cf.Surname, cf.Name, cf.FatherName, cf.Birth_Date, cf.ID_Sex, ps.PassNumForFilter, ps.PassDate, ps.PassFrom, ps.DepCode
FROM dbo.td_clients_FL cf TABLESAMPLE (10 percent)
        join dbo.TD_Passports ps 
        on cf.id_client = ps.id_client
WHERE 
ps.passdate is not null and 
ps.PassNumForFilter is not null and 
ps.DepCode is not null and 
ps.DepCode <> '' and 
ps.ID_Pass_Type = 10401 and
-- клиент не входит в запрещенные классификации
(select count(*)
 from dbo.td_Client_Groups cg
        INNER JOIN TD_Client_Classification
        ON cg.ID_Client_Classif = TD_Client_Classification.ID_Client_Classif
        INNER JOIN TD_Client_Classification TD_Client_Classification_1
        ON TD_Client_Classification.Parent_ID = TD_Client_Classification_1.ID_Client_Classif
        LEFT JOIN TD_Client_Classification TD_Client_Classification_2
        ON TD_Client_Classification_1.Parent_ID = TD_Client_Classification_2.ID_Client_Classif
 WHERE
 cg.ID_Client = cf.ID_Client and
 (
	-- тип клиента Свой
	((CASE	
      WHEN isnull(TD_Client_Classification_2.ClassifType, 0) = 0 THEN
        TD_Client_Classification_1.ClassifType
      ELSE
        TD_Client_Classification_2.ClassifType
      END) = 100 and cg.ID_Client_Classif = 14955498) or

	  -- категория клиента Премиум
	  ((CASE
      WHEN isnull(TD_Client_Classification_2.ClassifType, 0) = 0 THEN
        TD_Client_Classification_1.ClassifType
      ELSE
        TD_Client_Classification_2.ClassifType
      END) = 200 and cg.ID_Client_Classif = 1802460316) 
 )) = 0 and
 -- клиент - зарплатник
 (
 select count(*)
 from dbo.td_Client_Groups cg
        INNER JOIN TD_Client_Classification
        ON cg.ID_Client_Classif = TD_Client_Classification.ID_Client_Classif      
 WHERE
 cg.ID_Client = cf.ID_Client and TD_Client_Classification.ClassifType = 600
 ) > 0
";

        public bool ping(out string details)
        {
            details = "";
            var query = @"
select top 1 
    *
from
    dbo.td_clients_fl
";

            try
            {
                _con.cmd(query)
                    .retrieve();
                return true;
            }
            catch (Exception e)
            {
                details = e.Message;
                return false;
            }
        }

        #endregion
    }
}
