﻿using executor;
using jeyjen.db;
using jeyjen.extension;
using System;
using System.Collections.Generic;
using System.Text;
using static jeyjen.db.connection;

namespace server.driver
{
    public class own_db_driver
    {
        connection _con;
        public own_db_driver(string cs)
        {
            _con = new connection(provider.sqlserver, cs);
        }
        #region template
        public bundle get_template(int type, string owner)
        {
            var query = @"
select
  t.id,
  t.name,
  t.product_type as type,
  t.description
from 
  template as t 
where 
  t.owner = :owner 
  and t.product_type = :type";
            return _con.cmd(query)
                .param("owner", owner)
                .param("type", type)
                .retrieve();
        }
        public bundle get_template_attribute(int template_id)
        {
            var query = @"
select
    ta.name, 
    ta.value
from
    template_attribute ta 
where 
    ta.template_id = :template";

            return _con.cmd(query)
                .param("template", template_id)
                .retrieve();
        }
        public int create_template(int type, string name, string description, string owner, bundle attrs)
        {
            #region query
            string insert_tempalate = @"
insert into template 
(
    name, 
    product_type, 
    description,
    owner
) 
values 
(
    :name, 
    :type, 
    :description,
    :owner
);
select ident_current('template');"; 
            #endregion
            int id = _con.cmd(insert_tempalate)
                .param("name", name)
                .param("type", type)
                .param("description", description.is_null_or_empty() ? "" : description)
                .param("owner", owner)
                .scalar<int>();

            #region query
            string insert_tempalate_attribute = @"
insert into template_attribute 
(
    template_id, 
    name, 
    value
) 
values 
(
    :template_id, 
    :name, 
    :value
);
"; 
            #endregion
            _con.cmd(insert_tempalate_attribute)
                .param("template_id", id) // проверить установку атрибута
                .execute(attrs);
            return id;
        }

        public void update_template(int id, int type, string name, string description, string owner, bundle attrs)
        {
            #region query
            var query = @"
update 
    template
set
    name = :name,
    product_type = :type,
    description = :description,
    owner = :owner    
where 
    id = :id";
            #endregion
            _con.cmd(query)
                .param("name", name)
                .param("type", type)
                .param("description", description.is_null_or_empty()?"": description)
                .param("owner", owner)
                .param("id", id)
                .execute();

            _con.cmd("delete from template_attribute where template_id = :id")
                .param("id", id)
                .execute(); 

            #region query
            string insert_tempalate_attribute = @"
insert into template_attribute 
(
    template_id, 
    name, 
    value
) 
values 
(
    :template_id, 
    :name, 
    :value
);
";
            #endregion
            _con.cmd(insert_tempalate_attribute)
                .param("template_id", id)
                .execute(attrs);

        }

        public void delete_template(int id)
        {
            var delete_template = @"
delete from 
    template
where
    id = :id";

            _con.cmd(delete_template)
                .param("id", id)
                .execute();

            var delete_template_attribute = @"
delete from 
    template_attribute
where
    template_id = :id";

            _con.cmd(delete_template_attribute)
                .param("id", id)
                .execute();
        }
        #endregion
        #region card
        public bundle get_unused_cards(int code/*197 - обычные, 184 - для уважительного*/)
        {
            var cmd = @"
select
    card_id,
    is_used,
    add_number
from
    card_buffer cb
where
    cb.is_used = 0 
    and cb.add_number = :code
";
            return _con.cmd(cmd)
                .param("code", code)
                .retrieve();
        }

        public void set_card_as_used(long id)
        {
            var cmd = @"
update 
    card_buffer
set
    is_used = 1
where
    card_id = :id
";
            _con.cmd(cmd)
                .param("id", id)
                .execute();
        }

        #endregion
        #region attribute
        private bundle get_attributes(dentity param)
        {
            string query = @"
SELECT
    oa.name,
    av.value 
FROM
    order_attribute oa
LEFT JOIN
    attribute_value av 
ON
    av.attribute_id = oa.id
JOIN 
    release rs
ON 
    rs.id = oa.release_start
JOIN 
    release re
ON 
    re.id = oa.release_end
WHERE 
    oa.product_type = :type
    $cond$";


            var sb = new StringBuilder();
            if (param.contains("release"))
            {
                sb.Append(@"
    AND rs.number <= :release
    AND re.number >= :release
");
            }

            query = query.param("cond", sb.ToString());

            var cmd = _con.cmd(query);
            set_params(cmd, param.properties);
            return cmd.retrieve();
        }

        private bundle get_all_attribute_datatype()
        {
            string query = @"
SELECT
    oa.name,
    oa.data_type,
    oa.product_type
FROM
    order_attribute oa";

            return _con.cmd(query)
                .retrieve();
        }
        #endregion
        #region contour

        public bundle get_contours()
        {
             
            string query = @"
select 
    c.title, 
    cs.connection_string, 
    mx.connection_string as metodix, 
    ur.url
from 
    contour c
join 
    connection_string cs
on 
    c.connection_string_id = cs.id
join 
    connection_string mx
on  
    c.metodix_connection_string_id = mx.id
join
    url ur
on
    c.wss_url_id = ur.id
where 
  c.actual = 1";
            return _con.cmd(query)
                .retrieve();
        }

        public bundle get_attributes(string batch_name)
        {
            string query = @"
select 
    ba.attribute, 
    ba.data_type, 
    ba.value 
from 
    batch_attributes ba
join 
    batch b
on 
    b.id = ba.batch_id
where 
    b.name = :batch
";

            return _con.cmd(query)
                .param("batch", batch_name)
                .retrieve();
                

        }

        #endregion
        #region util
        private void set_params(command c, Dictionary<string, dynamic> param)
        {
            foreach (var p in param)
            {
                c.param(p.Key, p.Value);
            }
        }
        #endregion
        #region query
        public const string SelectTemplateValues = @"
select 
	oa.name, 
	ta.value 
from 
	template_attributes ta 
join templates tpl on 
		tpl.id = ta.template_id
join order_attributes oa on 
	ta.attribute_id = oa.id
where 
	tpl.id = :template  
";



        public const string AttributesByProductType = @"
select 
    attr.name, 
    dv.default_value, 
    attr.data_type 
from 
    order_attributes attr 
left join 
    attributes_default_value dv 
on 
    attr.id = dv.attribute_id
where attr.product_type_id = :producttype";




        #endregion
    }

}
