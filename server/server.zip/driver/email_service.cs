﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace server.driver
{
    public class email_service
    {
        public static void send_mail(string subject, string header, string body, string aus, Stream attach, string filename, bool with_image)
        {
            /*
mail_login = qa.reports@staff.all.corp
mail_password = qa.r`123
mail_host = mail.open.ru
mail_mail = qa.reports@open.ru
mail_work_users = Kirill.menshov@OPEN.RU;Mikhail.Brantov@open.ru;viktor.orlov@open.ru;ekaterina.ermilova@open.ru
mail_work_users2 = viktor.orlov@open.ru;natalya.e.bratchikova@open.ru;puchkov.sb@openbank.ru;ermilova.ei@otkritie.ru;Aleksandr.kamyshnikov@OPEN.RU;alexander.gorodilov@open.ru;lunev.sm@otkritie.ru;roman.zabuga@OPEN.RU
mail_at = viktor.orlov@open.ru;kseniya.cherchenko@open.ru;novikov.eo@OPEN.RU;Kirill.Koblov@open.ru;sergey.afanasev@open.ru;Aleksandr.Epifanov@open.ru
mail_test_users = viktor.orlov@open.ru
mail_monitoring_users = viktor.orlov@open.ru;artur.abdullin@OPEN.RU;Olga.Sytnikova@open.ru
mail_dev_users = viktor.orlov@open.ru
             */

            MailMessage msg = new MailMessage();
            var aUser = aus.Split(';');
            foreach (var user in aUser)
            {
                msg.To.Add(new MailAddress(user));
            }
            msg.From = new MailAddress("qa.reports@open.ru", "не понятно от кого", Encoding.UTF8);
            msg.Subject = subject;
            msg.Body = body;
            msg.IsBodyHtml = true;

            /*
            Attachment data = new Attachment(attach, MediaTypeNames.Application.Octet);
            data.Name = filename;
            msg.Attachments.Add(data);
            */
            var htmlView = AlternateView.CreateAlternateViewFromString(header + body, null, "text/html");
            /*
            if (with_image)
            {
                byte[] reader = File.ReadAllBytes("temp_image.png");

                //reader = CropImage(reader, new Rectangle(200, 140, 1250, 2000), false, 1, 1);

                MemoryStream bodyimage = new MemoryStream(reader);

                if (File.Exists(@"temp_image.png"))
                {
                    File.Delete(@"temp_image.png");
                }

                LinkedResource timage = new LinkedResource(bodyimage, MediaTypeNames.Image.Jpeg);
                timage.ContentType = new ContentType("image/jpg");
                timage.ContentId = "atimg";

                htmlView.LinkedResources.Add(timage);
            }
            */

            msg.AlternateViews.Add(htmlView);

            SmtpClient smtpClient = new SmtpClient
            {
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("qa.reports@staff.all.corp", "qa.r`123"),
                Port = 25,
                Host = "mail.open.ru",
                DeliveryMethod = SmtpDeliveryMethod.Network,
                EnableSsl = false
            };
            ServicePointManager.ServerCertificateValidationCallback =
                        delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
                        { return true; };
            try
            {
                smtpClient.Send(msg);
            }
            catch (Exception e)
            {
            }
            //attach.Close();
            //data.Dispose();
        }

        /*
        public static byte[] CropImage(byte[] byteArray, Rectangle selection, Boolean withResize, double rwidth, double rheight)
        {
            MemoryStream ms = new MemoryStream(byteArray);

            Bitmap bmp = Image.FromStream(ms) as Bitmap;

            Bitmap cropBmp = bmp.Clone(selection, bmp.PixelFormat);

            if (withResize)
            {
                double dwidth = cropBmp.Width * rwidth;
                double dheight = cropBmp.Height * rheight;
                cropBmp = new Bitmap(cropBmp, new Size(Convert.ToInt32(Math.Round(dwidth)), Convert.ToInt32(Math.Round(dheight))));
            }

            ImageConverter converter = new ImageConverter();

            return (byte[])converter.ConvertTo(cropBmp, typeof(byte[]));
        }
        */
    }
}
