﻿using jeyjen.db;
using jeyjen.extension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace server.driver
{
    public class soz_wss_driver
    {
        private string _host;
        public soz_wss_driver(string host)
        {
            _host = host;
        }

        public string save_application(bundle bundle)
        {
            string query = @"
<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:sup=""http://support.diasoft.ru"">
    <soapenv:Header/>
    <soapenv:Body>
        <sup:DSCALL>
            <sup:commandtext>APPLICATIONSAVE</sup:commandtext>
            <sup:commanddata><![CDATA[<?xml version = ""1.0"" encoding = ""UTF-8"" ?>
        <BODY version = ""2.11"">
            $attributes$
        </BODY>]]>
            </sup:commanddata>
        </sup:DSCALL>
    </soapenv:Body>
</soapenv:Envelope>";


            var attrs_text = new StringBuilder();
            string type = "";
            foreach (var row in bundle)
            {
                switch (row.get<int>("type", 1))
                {
                    case 1:
                        {
                            type = "java.lang.String";
                        } break;
                    case 4:
                        {
                            type = "java.lang.Boolean";
                        }
                        break;
                    case 7:
                        {
                            type = "java.util.Date";
                        }
                        break;
                    default:
                        {
                            type = "java.lang.String";
                        }break;
                }

                attrs_text.AppendFormat("<{0} type=\"{1}\">{2}</{0}>\r\n", row["attribute"], type, row["value"]);
            }
            return query.param("attributes", attrs_text.ToString());
        }

        public string set_stage(long document_id, string stage_name, string result, string performer, bundle attributes)
        {
            string query = @"
<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:sup=""http://support.diasoft.ru"">
    <soapenv:Header/>
    <soapenv:Body>
        <sup:DSCALL>
            <sup:commandtext>DOCPROCESSINGSAVE</sup:commandtext>
            <sup:commanddata><![CDATA[<?xml version = ""1.0"" encoding = ""UTF-8"" ?><BODY version = ""2.11"">
            <DOCUMENTID type=""java.lang.String"">$document_id$</DOCUMENTID>
            <STAGENAME type=""java.lang.String"">$stage_name$</STAGENAME>
            <STAGEDETAILS type=""java.lang.String""></STAGEDETAILS>
            <STAGERESULT type=""java.lang.String"">$stage_result$</STAGERESULT>
            <EXTRADETAILS type=""java.lang.String""></EXTRADETAILS>
            <EXTRARESULT type=""java.lang.String""></EXTRARESULT>
            <PERFORMER type=""java.lang.String"">$performer$</PERFORMER>
            $attributes$
        </BODY>]]></sup:commanddata>
        </sup:DSCALL>
    </soapenv:Body>
</soapenv:Envelope>";

            var sb = new StringBuilder();
            foreach (var row in attributes)
            {
                sb.AppendFormat("<{0} type=\"java.lang.String\">{1}</{0}>", row.get<string>("name"), row.get<string>("value"));
            }

            query = query
                .param("document_id", document_id)
                .param("stage_name", stage_name)
                .param("stage_result", result)
                .param("performer", performer)
                .param("attributes", sb.ToString());
            
            return query;
        }

        public string send_request(string query)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("SOAPAction", "");
                var content = new StringContent(query, Encoding.UTF8, "text/xml");
                var result = client.PostAsync(_host, content).Result;
                return result.Content.ReadAsStringAsync().Result;
            }
        }

        public string set_state(long order, string state)
        {
            var query = @"
<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:sup=""http://support.diasoft.ru"">
   <soapenv:Header/>
   <soapenv:Body>
      <sup:DSCALL>
         <sup:commandtext>DocumentStateModify</sup:commandtext>
      <sup:commanddata><![CDATA[
<?xml version=""1.0"" encoding =""UTF-8"" ?>
<BODY version=""2.11"">
  <DOCUMENTID type=""java.lang.String"">$order_id$</DOCUMENTID>
  <STATE type=""java.lang.String"">$state$</STATE>
</BODY>
]]>
</sup:commanddata>
      </sup:DSCALL>
   </soapenv:Body>
</soapenv:Envelope>";

            return query
                .param("order_id", order)
                .param("state", state);
        }

        public string update_order(long order_id, bundle bundle)
        {
            string query = @"
<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:sup=""http://support.diasoft.ru"">
    <soapenv:Header/>
    <soapenv:Body>
        <sup:DSCALL>
            <sup:commandtext>APPLICATIONUPDATE</sup:commandtext>
            <sup:commanddata><![CDATA[<?xml version = ""1.0"" encoding = ""UTF-8"" ?>
        <BODY version = ""2.11"">
            <DOCUMENTID type=""java.lang.Integer"">$order_id$</DOCUMENTID>
            $attributes$
        </BODY>]]>
            </sup:commanddata>
        </sup:DSCALL>
    </soapenv:Body>
</soapenv:Envelope>";


            var attrs_text = new StringBuilder();
            string type = "";
            foreach (var row in bundle)
            {
                switch (row.get<int>("type", 1))
                {
                    case 1:
                        {
                            type = "java.lang.String";
                        }
                        break;
                    case 4:
                        {
                            type = "java.lang.Boolean";
                        }
                        break;
                    case 7:
                        {
                            type = "java.util.Date";
                        }
                        break;
                    default:
                        {
                            type = "java.lang.String";
                        }
                        break;
                }

                attrs_text.AppendFormat("<{0} type=\"{1}\">{2}</{0}>\r\n", row["attribute"], type, row["value"]);
            }
            return query
                .param("attributes", attrs_text.ToString())
                .param("order_id", order_id);
        }

        public bool ping(out string details)
        {
            details = "";
            var url = new Uri(_host);
            var tcp = new TcpClient();
            try
            {
                tcp.Connect(url.Host, url.Port);
                tcp.Close();
                return true;
            }
            catch (Exception ex)
            {
                details = ex.Message;
                return false;
            }
        }
    }
}
