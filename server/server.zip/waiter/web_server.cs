﻿using executor;
using jeyjen.extension;
using jeyjen.net.server;
using NLog;
using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Security.Cryptography.X509Certificates;

namespace server.waiter
{
    public class web_server : jeyjen.net.server.web_server
    {
        private Logger _log = LogManager.GetLogger("http");
        public web_server(int port, X509Certificate2 certificate = null) : base(port, certificate)
        {
        }

        protected override void on_http_request(context context)
        {
            handle_request(context);
        }
        #region http request
        private void handle_request(context context)
        {
            var r = context.request;
            if (r.method == "POST")
            {
                handle_post_request(context);
            }
            else if (r.method == "GET")
            {
                handle_get_request(context);
            }
            else
            {
                _log.Error("recieved unsupported request");
            }
        }
        private void handle_post_request(context context)
        {
            try
            {
                var body = Encoding.UTF8.GetString(context.request.body);
                _log.Debug("request: {0}", body);
                var d = new dentity(body);
                handle_command(d, 
                    (c)=> 
                    {
                        http_responce(context, http_success(c));
                    },
                    (err)=> 
                    {
                        var err_text = err == null ? "undefined error" : err.Message;
                        http_responce(context, http_error(err_text), status.Internal_Server_Error);
                    });
            }
            catch (Exception ex)
            {
                _log.Error("undefined exception \"{0}\"", ex.Message);
                http_responce(context, http_error(ex.Message), status.Internal_Server_Error);
            }
        }
        private void handle_command(dentity cmd, Action<dentity> result_callback, Action<Exception> error_callback)
        {
            if (!cmd.contains("header"))
            {
                _log.Error("request doesn`t have \"header\" key");
                throw new Exception("сообщение не содержит заголовка \"header\"");
            }
            dentity h = cmd["header"];
            if (!h.contains("context"))
            {
                _log.Error("request doesn`t have \"context\" key");
                throw new Exception("сообщение не содержит поля \"context\"");
            }
            if (!h.contains("action"))
            {
                _log.Error("request doesn`t have \"action\" key");
                throw new Exception("сообщение не содержит поля \"action\"");
            }
            if (!cmd.contains("content"))
            {
                cmd.set("content", new dentity());
            }
            var initiator = "john_due";
            bpm.perform("net_handler", initiator, h.get<string>("context"), h.get<string>("action"), cmd.get<dentity>("content"), result_callback, error_callback);
        }
        private void handle_get_request(context context)
        {
            var url = context.request.url;
            string file_path = "";
            if (url == "/")
            {
                file_path = "src/index.html";
            }
            else
            {
                file_path = "src" + url;
            }

            byte[] data = null;
            if (File.Exists(file_path))
            {
                var ext = Path.GetExtension(file_path);
                if (ext == ".html" || ext == ".js" || ext == ".css")
                {
                    TextReader tr = new StreamReader(file_path);
                    string msg = tr.ReadToEnd();
                    data = Encoding.UTF8.GetBytes(msg);
                    switch (ext)
                    {
                        case ".html":
                            {
                                context.responce.content_type = "text/html";
                            }
                            break;
                        case ".js":
                            {
                                context.responce.content_type = "text/javascript";
                            }
                            break;
                        case ".css":
                            {
                                context.responce.content_type = "text/css";
                            }
                            break;
                    }
                }
                else
                {
                    data = File.ReadAllBytes(file_path);
                }
            }
            else
            {
                data = new byte[1024];
            }
            http_responce(context, data);
        }
        #endregion
        #region http responce
        public void http_responce(context context, string content, status status_code = status.OK)
        {
            try
            {
                var r = context.responce;
                _log.Debug("responce: {0}", content);
                byte[] buf = Encoding.UTF8.GetBytes(content);
                r["Access-Control-Allow-Origin"] = "*";
                r["Content-type"] = "application/json; charset=utf-8";
                r.status = status_code;
                r.send(buf);
            }
            catch (Exception ex)
            {
                _log.Error("unhandled exception on responce {0}", ex.Message);
            }
            finally
            {
                context.close();
            }
        }
        public void http_responce(context context, byte[] data, status status_code = status.OK)
        {
            try
            {
                var r = context.responce;
                r.status = status_code;
                r.send(data);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                context.close();
            }
        }

        public string http_success(dentity content)
        {
            if (content == null)
            {
                return "{\"header\":{\"result\":\"success\"},\"content\":{}}";
            }
            else
            {
                return string.Format("{{\"header\":{{\"result\":\"success\"}},\"content\":{0}}}", content.ToJson());
            }
        }
        public string http_error(string error_text)
        {
            error_text = error_text.Replace("\\", "\\\\").Replace("\"", "\\\"");
            return "{{\"header\":{{\"result\":\"error\", \"error_text\":\"{0}\"}}}}".format(error_text);
        }
        #endregion

        #region websocket
        protected override void on_websocket_connect(websocket socket)
        {
            // добавить пользователя в коллекцию
        }

        protected override void on_websocket_disconnect(websocket socket, string reason)
        {
            // удалить пользователя   
        }

        protected override void on_message(websocket socket, string message, bool last_frame)
        {
            string id = null;
            try
            {
                var cmd = new dentity(message);
                id = cmd["header"]["id"];
                handle_command(cmd,
                    (c) =>
                    {
                        ws_responce(socket, ws_success(id, c));
                    },
                    (err) =>
                    {
                        var err_text = err == null ? "undefined error" : err.Message;
                        ws_responce(socket, ws_error(id, err_text));
                    });
            }
            catch (Exception ex)
            {
                _log.Error("undefined exception \"{0}\"", ex.Message);
                ws_responce(socket, ws_error(id, ex.Message));
            }
        }
        #endregion

        #region websocket_response
        public void ws_responce(websocket ws, byte[] data)
        {
            try
            {
                ws.send(data);
            }
            catch (Exception ex)
            {
            }
        }
        public void ws_responce(websocket ws, string message)
        {
            ws_responce(ws, Encoding.UTF8.GetBytes(message));
        }

        public string ws_success(string action_id, dentity content)
        {
            if (content == null)
            {
                return "{{\"header\":{{\"result\":\"success\",\"id\":\"{0}\"}},\"content\":{{}}}}".format(action_id);
            }
            else
            {
                return string.Format("{{\"header\":{{\"result\":\"success\",\"id\":\"{0}\"}},\"content\":{1}}}", action_id, content.ToJson());
            }
        }
        public string ws_error(string action_id, string error_text)
        {
            error_text = error_text.Replace("\\", "\\\\").Replace("\"", "\\\"");
            return "{{\"header\":{{\"result\":\"error\", \"error_text\":\"{0}\", \"id\":\"{1}\"}}}}".format(error_text, action_id);
        }
        #endregion
    }

    //public class http_server
    //{
    //    private Thread _server;
    //    private readonly HttpListener _listener = new HttpListener();
    //    private Logger _log =  LogManager.GetLogger("http");

    //    public http_server(params string[] prefixes)
    //    {
    //        if (! HttpListener.IsSupported)
    //        {
    //            _log.Error("HttpListener not supported");
    //            throw new NotSupportedException("HttpListener не поддерживается на данной машине");
    //        }

    //        if (prefixes == null || prefixes.Length == 0)
    //        {
    //            _log.Error("url not defined");
    //            throw new ArgumentException("prefixes");
    //        }

    //        foreach (string s in prefixes)
    //        {
    //            _listener.Prefixes.Add(s);
    //        }

    //        var auth = ConfigurationManager.AppSettings["auth"].ToLower();
    //        if (auth.Equals("true"))
    //        {
    //            _listener.AuthenticationSchemes = AuthenticationSchemes.Ntlm;
    //        }
    //    }
    //    public void start()
    //    {
    //        _server = new Thread(() =>
    //        {
    //            try
    //            {
    //                _listener.Start();
    //                _log.Info("httpserver started");
    //                while (_listener.IsListening)
    //                {
    //                    var ctx = _listener.GetContext();
    //                    if (ctx != null)
    //                    {
    //                        handle_request(ctx);
    //                    }
    //                }
    //            }
    //            catch (Exception e)
    //            {
    //                Console.WriteLine("error: {0}", e.Message);
    //            }
    //        });
    //        _server.Start();
    //    }
    //    public void stop()
    //    {
    //        _listener.Stop();
    //        _listener.Close();
    //    }

    //    private void handle_request(HttpListenerContext context)
    //    {
    //        if (context.Request.HttpMethod == "POST")
    //        {
    //            handle_post_request(context);
    //        }
    //        else if (context.Request.HttpMethod == "GET")
    //        {
    //            handle_get_request(context);
    //        }
    //        else
    //        {
    //            _log.Error("recieved unsupported request");
    //        }
    //    }

    //    #region request
    //    private void handle_post_request(HttpListenerContext context)
    //    {
    //        try
    //        {
    //            var body = get_body(context.Request);
    //            _log.Debug("request: {0}", body);
    //            dentity d = new dentity(body);
    //            if (!d.contains("header"))
    //            {
    //                _log.Error("request doesn`t have \"header\" key");
    //                throw new Exception("сообщение не содержит заголовка \"header\"");
    //            }
    //            dentity h = d["header"];
    //            if (!h.contains("context"))
    //            {
    //                _log.Error("request doesn`t have \"context\" key");
    //                throw new Exception("сообщение не содержит поля \"context\"");
    //            }
    //            if (!h.contains("action"))
    //            {
    //                _log.Error("request doesn`t have \"action\" key");
    //                throw new Exception("сообщение не содержит поля \"action\"");
    //            }
    //            if (!d.contains("content"))
    //            {
    //                d.set("content", new dentity());
    //            }
    //            var initiator = "john_due";
    //            if (context.User != null)
    //            {
    //                initiator = context.User.Identity.Name;
    //            }
    //            bpm.perform("net_handler", initiator, h.get<string>("context"), h.get<string>("action"), d.get<dentity>("content"),
    //            (c) =>
    //            {
    //                responce(context.Response, success(c));
    //            },
    //            (err) =>
    //            {
    //                var err_text = err == null ? "undefined error" : err.Message;
    //                responce(context.Response, error(err_text), 500);
    //            });

    //        }
    //        catch (Exception ex)
    //        {
    //            _log.Error("undefined exception \"{0}\"", ex.Message);
    //            responce(context.Response, error(ex.Message), 500);
    //        }
    //    }

    //    private void handle_get_request(HttpListenerContext context)
    //    {
    //        var url = context.Request.Url;
    //        string file_path = "";
    //        if (url.AbsolutePath == "/")
    //        {
    //            file_path = "src/index.html";
    //        }
    //        else
    //        {
    //            file_path = "src" + url.AbsolutePath;
    //        }

    //        byte[] data = null;
    //        if (File.Exists(file_path))
    //        {
    //            var ext = Path.GetExtension(file_path);
    //            if (ext == ".html" || ext == ".js" || ext == ".css")
    //            {
    //                TextReader tr = new StreamReader(file_path);
    //                string msg = tr.ReadToEnd();
    //                data = Encoding.UTF8.GetBytes(msg);
    //                switch (ext)
    //                {
    //                    case ".html":
    //                        {
    //                            context.Response.ContentType = "text/html";
    //                        } break;
    //                    case ".js":
    //                        {
    //                            context.Response.ContentType = "text/javascript";
    //                        }
    //                        break;
    //                    case ".css":
    //                        {
    //                            context.Response.ContentType = "text/css";
    //                        }
    //                        break;
    //                }
    //            }
    //            else
    //            {
    //                data = File.ReadAllBytes(file_path);
    //            }
    //        }
    //        else
    //        {
    //            data = new byte[1024];
    //        }

    //        responce(context.Response, data);
    //    }

    //    private string get_body(HttpListenerRequest req)
    //    {
    //        string content = "";
    //        using (StreamReader reader = new StreamReader(req.InputStream, Encoding.UTF8))
    //        {
    //            content = reader.ReadToEnd();
    //        }
    //        return content;
    //    } 
    //    #endregion
    //    #region responce
    //    public void responce(HttpListenerResponse resp, string content, int status_code = 200)
    //    {
    //        try
    //        {
    //            _log.Debug("responce: {0}", content);
    //            byte[] buf = Encoding.UTF8.GetBytes(content);
    //            resp.ContentLength64 = buf.Length;
    //            resp.AddHeader("Access-Control-Allow-Origin", "*");
    //            resp.AddHeader("Content-type", "application/json; charset=utf-8");
    //            resp.ContentEncoding = Encoding.UTF8;
    //            resp.StatusCode = status_code;
    //            resp.OutputStream.Write(buf, 0, buf.Length);
    //            resp.OutputStream.Flush();
    //        }
    //        catch (Exception ex)
    //        {
    //            _log.Error("unhandled exception on responce {0}", ex.Message);
    //        }
    //        finally
    //        {
    //            resp.Close();
    //        }
    //    }
    //    public void responce(HttpListenerResponse resp, byte[] data, int status_code = 200)
    //    {
    //        try
    //        {
    //            resp.ContentLength64 = data.Length;
    //            resp.StatusCode = status_code;
    //            resp.OutputStream.Write(data, 0, data.Length);
    //            resp.OutputStream.Flush();
    //        }
    //        catch (Exception ex)
    //        {

    //        }
    //        finally
    //        {
    //            resp.Close();
    //        }
    //    }

    //    public string success(dentity content)
    //    {
    //        if (content == null)
    //        {
    //            return "{\"header\":{\"result\":\"success\"},\"content\":{}}";
    //        }
    //        else
    //        {
    //            return string.Format("{{\"header\":{{\"result\":\"success\"}},\"content\":{0}}}", content.ToJson());
    //        }
    //    }
    //    public string error(string error_text)
    //    {
    //        error_text = error_text.Replace("\\", "\\\\").Replace("\"", "\\\"");
    //        return string.Format("{{\"header\":{{\"result\":\"error\", \"error_text\":\"{0}\"}}}}", error_text);
    //    }
    //    #endregion
    //}
}
