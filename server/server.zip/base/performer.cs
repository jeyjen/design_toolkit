﻿using jeyjen.extension;
using System;
using System.Threading;

namespace executor
{
    public class performer
    {
        #region field
        private Guid _id;
        private string _role;
        private EventWaitHandle _eh;
        private bool _is_canceled;
        private Thread _performer_thread;
        private task_context _task;
        private bool _is_alive;
        #endregion
        #region constructor
        public performer()
        {
            _eh = new AutoResetEvent(false);
            _is_alive = false;
        }
        #endregion
        #region property
        public Guid id
        {
            get
            {
                return _id;
            }
            internal set
            {
                _id = value;
            }
        }
        public string role
        {
            get
            {
                return _role;
            }
            internal set
            {
                _role = value;
            }
        }
        public bool is_alive
        {
            get
            {
                return _is_alive;
            }
        }
        public bool is_free
        {
            get
            {
                return _task == null;
            }
        }
        

        #endregion
        #region public method
        public void start()
        {
            _is_canceled = false;
            _eh.Reset();

            if (_performer_thread == null)
            {
                _performer_thread = new Thread((o) => { performer_cycle(o); });
                _performer_thread.IsBackground = false;
                _performer_thread.Start();
            }
            if (_task != null)
            {
                _eh.Set();
            }
            _is_alive = true;
        }
        public void stop()
        {
            _is_canceled = true;
            _is_alive = false;
            _eh.Set();
        }
        public void perform(task_context task)
        {
            _task = task;
            _eh.Set();
        }
        #endregion
        protected virtual void operation(string initiator, string context, string action, dentity content, Action<dentity> result_callback, Action<Exception> error_callback)
        {
            throw new NotImplementedException("основная операция у исполнителя \"{0}\" не реализована".format(_role));
        }
        private void performer_cycle(object param)
        {
            string id = (string)param;
            while (!_is_canceled)
            {
                _eh.WaitOne();
                if (!_is_canceled)
                {
                    try
                    {
                        if (_task.operation == null)
                        {
                            operation(_task.initiator, _task.context, _task.action, _task.content, _task.result_callback, _task.error_callback);
                        }
                        else
                        {
                            _task.operation(_task.initiator, _task.context, _task.action, _task.content, _task.result_callback, _task.error_callback);
                        }
                    }
                    catch (Exception e)
                    {
                        _task.error_callback(e);
                    }
                    if (_is_canceled)
                    {
                        continue;
                    }
                    var qt = bpm._common_tasks[_role];
                    var qp = bpm._roles[_role];
                    lock (qt) 
                    {
                        lock (qp)
                        {
                            if (qt.Count > 0)
                            {
                                _task = qt.Dequeue();
                                _eh.Set();
                                continue;
                            }
                            else
                            {
                                _task = null;
                            }
                        }
                    }
                }
            }
        }
    }
}
