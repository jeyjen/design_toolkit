﻿using jeyjen.extension;
using System;
using System.Collections.Generic;


namespace executor
{
    public class task_context
    {
        #region field
        private string _id;
        private string _context;
        private string _action;
        private string _initiator;
        private Action<string, string, string, dentity, Action<dentity>, Action<Exception>> _operation;
        public dentity _content;
        private Action<dentity> _result_callback;
        private Action<Exception> _error_callback;
        #endregion
        #region constructor
        public task_context(string id, string initiator, string context, string action, dentity content, Action<string, string, string, dentity, Action<dentity>, Action<Exception>> operation, Action<dentity> result_callback = null, Action<Exception> error_callback = null)
        {
            _initiator = initiator;
            _context = context;
            _action = action;
            _id = id;
            _content = content;
            _operation = operation;
            _result_callback = result_callback;
            _error_callback = error_callback;
        } 
        #endregion
        #region property
        public string id
        {
            get
            {
                return _id;
            }
        }
        public string context
        {
            get
            {
                return _context;
            }
        }
        public string action
        {
            get
            {
                return _action;
            }
        }

        public string initiator
        {
            get
            {
                return _initiator;
            }
        }

        public dentity content
        {
            get
            {
                return _content;
            }
        }
        
        public Action<string, string, string, dentity, Action<dentity> , Action<Exception>> operation
        {
            get
            {
                return _operation;
            }
        }

        public Action<dentity> result_callback
        {
            get
            {
                return _result_callback;
            }
        }

        public Action<Exception> error_callback
        {
            get
            {
                return _error_callback;
            }
        }
        #endregion
    }
}
