﻿using jeyjen.extension;
using System;
using System.Collections.Generic;

namespace executor
{
    public static class bpm
    {
        #region constant
        internal const string default_service_name = "base";
        internal const string default_role_name = "default";
        internal const string bpm_role_name = "bpm";
        #endregion
        #region field
        internal static Dictionary<Guid, performer> _performers;
        internal static Dictionary<string, Dictionary<Guid, performer>> _roles;
        internal static Dictionary<string, Queue<task_context>> _common_tasks;
        internal static bool _is_alive;
        #endregion
        static bpm()
        {
            _performers = new Dictionary<Guid, performer>();
            _roles = new Dictionary<string, Dictionary<Guid, performer>>();
            _roles.Add(default_role_name, new Dictionary<Guid, performer>());
            _common_tasks = new Dictionary<string, Queue<task_context>>();
            _common_tasks.Add(default_role_name, new Queue<task_context>());
            _is_alive = false;
        }
        #region manage
        public static void start(int default_count = 1, int bpm_count = 0)
        {
            // добавление испольнителей по умолчанию
            for (int i = 0; i < default_count; i++)
            {
                add_performer(default_role_name);
            }
            // добавление исполнителя для bpm
            for (int i = 0; i < bpm_count; i++)
            {
                add_performer(bpm_role_name);
            }
            foreach (var p in _performers)
            {
                p.Value.start();
            }
            _is_alive = true;
        }
        public static void stop()
        {
            // очистить все задачи
            foreach (var t in _common_tasks)
            {
                t.Value.Clear();
            }
            foreach (var p in _performers)
            {
                p.Value.stop();
            }
            _is_alive = false;
        }
        #endregion
        
        #region sync
        //public static dentity perform_sync(string context, string action, dentity content)
        //{
        //    return perform_sync(Guid.NewGuid().ToString(), context, action, content);
        //}
        //public static dentity perform_sync(string id, string context, string action, dentity content)
        //{
        //    var t = new task_context(id, context, action, content);
        //    return make_decision(t);
        //}
        //private static dentity make_decision(task_context task)
        //{
        //    while (task.stack.Count > 0)
        //    {
        //        task.current_node = task.stack.Pop();
        //        switch (task.current_node.type)
        //        {
        //            case op_type._operation:
        //                {
        //                    try
        //                    {
        //                        if (!task.current_node.pre_con(task))
        //                        {
        //                            throw new process_exception("не выполнено предусловие", task.current_node);
        //                        }
        //                        task.current_node.execute(task);
        //                        if (!task.current_node.post_con(task))
        //                        {
        //                            throw new process_exception("не выполнено постусловие", task.current_node);
        //                        }
        //                    }
        //                    catch (process_exception e)
        //                    {
        //                        task.exception = e;
        //                    }
        //                    catch (Exception e)
        //                    {
        //                        task.exception = new process_exception(e.Message, task.current_node);
        //                    }

        //                    if (task.exception != null)
        //                    {
        //                        task.stack.Clear();
        //                        if (_error_scenario == null)
        //                        {
        //                            throw task.exception;
        //                        }
        //                        else
        //                        {
        //                            task.stack.Push(_error_scenario);
        //                        }
        //                    }
        //                }
        //                break;
        //            case op_type._process:
        //                {
        //                    for (int i = task.current_node.sub.Count - 1; i >= 0; i--)
        //                    {
        //                        task.stack.Push(task.current_node.sub[i]);
        //                    }
        //                }
        //                break;
        //            case op_type._if:
        //                {
        //                    var result = ((node_if)task.current_node).con(task);
        //                    if (result)
        //                    {
        //                        if (task.stack.Count > 0 && task.stack.Peek().type == op_type._else)
        //                        {
        //                            task.stack.Pop();
        //                        }
        //                        for (int i = task.current_node.sub.Count - 1; i >= 0; i--)
        //                        {
        //                            task.stack.Push(task.current_node.sub[i]);
        //                        }
        //                    }
        //                }
        //                break;
        //            case op_type._else:
        //                {
        //                    for (int i = task.current_node.sub.Count - 1; i >= 0; i--)
        //                    {
        //                        task.stack.Push(task.current_node.sub[i]);
        //                    }
        //                }
        //                break;
        //            case op_type._switch:
        //                {
        //                    var result = ((node_switch)task.current_node).con(task);
        //                    if (result)
        //                    {
        //                        // удаляем все остальные блоки switch
        //                        while (task.stack.Count > 0 && task.stack.Peek().type == op_type._switch)
        //                        {
        //                            task.stack.Pop();
        //                        }
        //                        for (int i = task.current_node.sub.Count - 1; i >= 0; i--)
        //                        {
        //                            task.stack.Push(task.current_node.sub[i]);
        //                        }
        //                    }
        //                }
        //                break;
        //            case op_type._delegate:
        //                {
        //                    var n = (node_delegate)task.current_node;
        //                    var s = _driver[n.service];
        //                    var content = new dentity();
        //                    n.pre(task, content);
        //                    var res = s.perform_sync(n.context, n.action, content);
        //                    n.post(res, task);
        //                }
        //                break;
        //        }
        //    }
        //    return task.content;
        //}
        #endregion
        #region async
        public static void perform(string role, string initiator, string context, string action, dentity content, Action<dentity> result_callback, Action<Exception> error_callback)
        {
            perform(role, Guid.NewGuid().ToString(), initiator, context, action, content, result_callback, error_callback);
        }
        public static void perform(string role, string id, string initiator, string context, string action, dentity content, Action<dentity> result_callback, Action<Exception> error_callback)
        {
            var t = new task_context(id, initiator, context, action, content, null, result_callback, error_callback);
            assign_to_performer(role, t);
            // найти исполнителя и поместить задачу в очередь
        }
        public static void perform(string role, string initiator, string context, string action, dentity content, Action<string, string, string, dentity, Action<dentity>, Action<Exception>> operation,  Action<dentity> result_callback, Action<Exception> error_callback)
        {
            perform(role, Guid.NewGuid().ToString(), initiator, context, action, content, operation, result_callback, error_callback);
        }
        public static void perform(string role, string id, string initiator, string context, string action, dentity content, Action<string, string, string, dentity, Action<dentity>, Action<Exception>> operation, Action<dentity> result_callback, Action<Exception> error_callback)
        {
            var t = new task_context(id, initiator, context, action, content, operation, result_callback, error_callback);
            assign_to_performer(role, t);
            // найти исполнителя и поместить задачу в очередь
        }
        #endregion
        #region assign
        private static void assign_to_performer(string role, task_context task)
        {
            Dictionary<Guid, performer> dp = null;
            Queue<task_context> qt = null;
            lock (_roles)
            {
                if (_roles.ContainsKey(role))
                {
                    dp = _roles[role];
                    lock (_common_tasks)
                    {
                        qt = _common_tasks[role];
                    }
                }
            }

            if (dp == null)
            {
                // поместить в стандартные потоки
                assign_to_performer(default_role_name, task);
            }
            else
            {
                lock (dp)
                {
                    lock (qt)
                    {
                        var p = find_free_performer(dp);
                        if (qt.Count == 0 && p != null)
                        {
                            p.perform(task);
                        }
                        else
                        {
                            qt.Enqueue(task);
                        }
                    }
                }
            }
        }
        private static performer find_free_performer(Dictionary<Guid, performer> performers)
        {
            foreach (var p in performers)
            {
                if (p.Value.is_alive && p.Value.is_free)
                {
                    return p.Value;
                }
            }
            return null;
        }
        #endregion
        #region perform setting
        
        #region добавление / удаление исполнителей
        public static void add_performer(string role, performer performer = null)
        {
            if (performer == null)
            {
                performer = new performer();
            }
            performer.id = Guid.NewGuid();
            performer.role = role;
            _performers.Add(performer.id, performer);
            if (_roles.ContainsKey(role))
            {
                _roles[role].Add(performer.id, performer);
            }
            else
            {
                var d = new Dictionary<Guid, performer>();
                d.Add(performer.id, performer);
                _roles.Add(role, d);
            }
            // добаление спец очереди
            if (!_common_tasks.ContainsKey(role))
            {
                _common_tasks.Add(role, new Queue<task_context>());
            }
            if (_is_alive)
            {
                performer.start();
            }
        }

        public static void remove_performer(Guid id)
        {
            // остановить исполнителя если запущен
            var p = _performers[id];
            lock (_performers)
            {
                _performers.Remove(id);
            }
            lock (_roles)
            {
                _roles[p.role].Remove(id);
            }
        }
        #endregion

        public static bool performer_is_alive(Guid performer_id)
        {
            return _performers[performer_id].is_alive;
        }
        #endregion

    }

    public class nc
    {
        public string id { get; set; }
        public  int type { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string prec { get; set; }
        public string pre { get; set; }
        public string main { get; set; }
        public string post { get; set; }
        public string postc { get; set; }
        public string inv { get; set; }

    }
}
